Rhapsody Health

Patch for ngs #11.2.10 Readme

NOTE: Before using this information and the product it supports, read the information in
the Notices section at the end of this document.

===============================================================================================
Table of Contents
===============================================================================================

    A.   Introduction
    B.   Installation Instructions
    C.   Manual Changes
    D.   Verification
    E.   Notices

===============================================================================================
A. Introduction
===============================================================================================

    Rolled Up HotFixes  : NONE

    Issue(s)            : Patch ngs-11.2.10 - NGS 11.2.10 Patch Install

    Product             : ngs

    Version             : Release v11.2.10_rev356

    Patch Revision      : 356

    Dependencies        : NONE

    Prerequisites       : NONE

===============================================================================================
B. Installation Instructions
===============================================================================================

    Install:
        1. If there is a patch already installed, it must be uninstalled before installing this patch. To see if a patch is currently installed, you can run "list" in the ngs console and look at the bundle versions.
        2. Unzip zip file into NextGate Root folder (ex: /var/nextgate)
        3. Open a command prompt, go to [NextGate Root]/products
        4. Run install.[sh | bat] ngs-patch-11.2.10
        5. Restart NGS
        6. From the MM SDK folder, run the following:

                ngcmd.[sh|bat] -Dunattended=true -Dproject=[person|provider] upgrade-db project install-project

    Uninstall:
        1. Open a command prompt, go to [NextGate Root]/products
        2. Run install.[sh | bat] ngs-patch-11.2.10-uninstall
        3. Restart NGS

    NOTES:
        o  The Uninstall will take you back to the base "x.x.0" version. Therefore, if you
           had say "x.x.1" and are uninstalling "x.x.2", to get back to "x.x.1", you must
           uninstall "x.x.2", then install "x.x.1".

        o  If you run any other install or uninstall command after applying this patch, you
           MUST re-run this patch install to ensure all the updates are applied correctly
           again.

===============================================================================================
C. Manual Changes
===============================================================================================

    Make changes to the following files.

        Config changes  : None

===============================================================================================
D. Verification
===============================================================================================

    Post Install Verification   :

        o  From the NGS Console, do a 'list' the active bundles

        o  From the list, check the 'build: #' to ensure it is the SAME as the Patch build
           revision for all bundles contained in Patch.

                - Bundles within this patch:
                    NextGate :: Core (356)
                    NextGate :: Support :: Collector (356)
                    NextGate :: Interfaces :: NGS (356)
                    NextGate :: Interfaces :: NGAM (356)
                    NextGate :: Interfaces :: NGAUG (356)
                    NextGate :: Interfaces :: Hosted Services (356)
                    NextGate :: Hosted :: Phonehome :: Client (356)
                    NextGate AM :: Service :: Manager (356)
                    NextGate MM :: UI :: Data Quality Manager (356)
                    NextGate MM :: IS :: Adapter :: HL7 MLLP Listener (356) [only if previously installed]
                    NextGate MM :: IS :: Adapter :: HL7 MLLP Sender (356) [only if previously installed]
                    NextGate MM :: IS :: Notifications (356) [only if previously installed]
                    NextGate MM :: IS :: Mapper :: Notification Legacy (356)
                    NextGate MM :: Index-Core (356)
                    NextGate MM :: Standardizer (356)
                    NextGate MM :: MM Common Package (356)
                    NextGate MM :: Data Quality Service (356)
                    NextGate MM :: Analyzer (356) [SDK update only - will not show in NGS Console 'list']
                    NextGate MM :: Project :: Generator (356) [SDK update only - will not show in NGS Console 'list']
                    NextGate MS :: Mapper :: MM Notification (356)
                    NextGate MS :: Adapter :: MatchMetrix Listener (356)
                    NextGate :: UI :: Framework :: Frontend (356)
                    NextGate Reporter :: Service :: Health Check (356) [only if previously installed]
                    NextGate Reporter :: Service (356) [only if previously installed]
                    NextGate Reporter :: UI :: Report Manager (356) [only if previously installed]
                    NextGate Augment :: Server :: Service (356) [only if previously installed]
                    NextGate Augment :: UI :: Augment Manager (356) [only if previously installed]
                    NextGate Augment :: Client :: Service (356) [only if previously installed]
                    NextGate Augment :: Providers :: Experian (356) [only if previously installed]
                    NextGate MS :: Adapter :: Workflow Sender (356) [only if previously installed]
                    NextGate :: Workflow :: UI :: Task Manager (356) [only if previously installed]
                    NextGate :: UI :: NGMC (356)

                - You can get a concise list by running the following in the NGS Console:
                        list | grep 356

    Patch test                  : None

===============================================================================================
E. Notices
===============================================================================================

(C) Copyright 2023, InterOperability Bidco, Inc. d.b.a. Rhapsody
