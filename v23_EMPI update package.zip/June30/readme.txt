Hi Christophe,
I sent you a Quatrix link with the updated package to address the approve task test. As noted, there is a manual step that will need to be performed to patch a product issue. The steps are provided below. After performing the steps, install the Enovacom package in the normal way.

Change to the EMPI install products folder
cp [path to file]/ngwf-service-11.2.11.jar ngs/system/com/nextgate/workflow/ngwf-service/11.2.11.383/ngwf-service-11.2.11.383.jar
rm -r ngs/data/repo/com/nextgate/workflow/ngwf-service/11.2.11.383/
ngs/bin/client
list |grep -i "workflow :: service"
update [bundle id]
Restart NGS
