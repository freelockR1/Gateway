cp ngms-mapper-mmnotification-11.2.0.jar ngs/system/com/nextgate/ms/components/mappers/ngms-mapper-mmnotification/11.2.0 
rm -r ngs/data/repo/com/nextgate/ms/components/mappers/ngms-mapper-mmnotification
ngs/bin/client
bundle:update com.nextgate.ms.components.mappers.ngms-mapper-mmnotification
restart NGS 