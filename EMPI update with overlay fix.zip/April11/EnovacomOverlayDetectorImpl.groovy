/*
    Copyright (c) 2016, NextGate Solutions All Rights Reserved.

    This program, and all the NextGate Solutions authored routines referenced herein,
    are the proprietary properties and trade secrets of NextGate Solutions.

    Except as provided for by license agreement, this program shall not be duplicated,
    used, reversed engineered, decompiled, disclosed, shared, transferred, placed in a
    publicly available location (such as but not limited to ftp sites, bit torrents,
    shared drives, peer to peer networks, and such) without  written consent signed by
    an officer of NextGate Solutions.

    DISCLAIMER:

    This software is provided as is without warranty of any kind. The entire risk as to
    the results and performance of this software is assumed by the licensee and/or its
    affiliates and/or assignees. NextGate Solutions disclaims all warranties, either
    expressed or implied, including but not limited to the implied warranties of
    merchantability, fitness for a particular purpose, title and non-infringement, with
    respect to this software.

    - version control -
    $Id$
 */

package com.sun.mdm.index.overlay;

import com.nextgate.core.utils.DateUtils;
import com.nextgate.interfaces.mm.exceptions.MatchException;
import com.nextgate.mm.common.datatypes.config.ApplicationConfig;
import com.nextgate.mm.common.datatypes.match.CompositeMatchWeight;
import com.nextgate.mm.common.datatypes.quality.OverlayDetectorResult;
import com.nextgate.mm.common.services.Engine;
import com.nextgate.mm.common.services.ExclusionRegistry;
import com.nextgate.mm.common.services.Matcher;
import com.sun.mdm.index.matching.ValueMapUtils;
import com.sun.mdm.index.objects.SystemObject;
import com.sun.mdm.index.objects.exception.ObjectException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Connection;
import java.text.DecimalFormat;

import com.nextgate.mm.common.datatypes.match.MatchWeight

/**
 * The type Overlay detector.
 */
public class OverlayDetectorImpl implements OverlayDetector {

    private Matcher mMatch;
    private ExclusionRegistry exclReg;
    private float mOverlayScoreThreshold;
    private float mOverlayDeltaThreshold;
    private float mOverlayRevertToDelta;
    private final DecimalFormat mNumFormat;
    private boolean rejectTrans = false;
    private boolean splitRecord = false;
    private boolean blockMerge = false;
    private boolean blockCalc = false;
    private boolean deactivateRecord = false;
    private boolean quarantineRecord = false;
    private Map<String,String> exclusionMap = new HashMap<>();
    private static transient final Logger mLogger = LoggerFactory.getLogger(OverlayDetectorImpl.class);

    /**
     * Instantiates a new Overlay detector.
     */
    public OverlayDetectorImpl() {
        mNumFormat = new DecimalFormat();
    }

    /**
     * 
     * @param beforeObj the before object
     * @param afterObj the after object
     * @return the detector result
     * @throws com.sun.mdm.index.overlay.OverlayDetectorException thrown on detection error
     */
    @Override
    public OverlayDetectorResult checkForOverlay(SystemObject beforeObj,
            SystemObject afterObj) throws OverlayDetectorException {

        mLogger.debug("Checking [{}:{}] for overlay. Using score threshold {} and delta threshold {}",
                afterObj.getSystemCode(), afterObj.getLID(), mOverlayScoreThreshold, mOverlayDeltaThreshold);
        mLogger.trace("Before object: {}\nAfterObject: {}", beforeObj, afterObj);

        OverlayDetectorResult res = new OverlayDetectorResult();
        res.setScoreThreshold(mOverlayScoreThreshold);
        res.setDeltaThreshold(mOverlayDeltaThreshold);
        try {
            res.setSystemCode(beforeObj.getSystemCode());
            res.setLID(beforeObj.getLID());
            
            CompositeMatchWeight origWeight = mMatch.getWeight(ValueMapUtils.getValueMap(beforeObj.getObject()),
                		ValueMapUtils.getValueMap(beforeObj.getObject()));

            res.setBaseComparison(origWeight);
            mLogger.trace("Base comparison weight: {}", origWeight.getWeight());

            if(!allowChangeWithoutCheck(beforeObj, afterObj)) {
                if (origWeight.getWeight() >= mOverlayScoreThreshold) {
                
                    CompositeMatchWeight recComparison = mMatch.getWeight(ValueMapUtils.getValueMap(beforeObj.getObject()),
                                ValueMapUtils.getValueMap(afterObj.getObject()));

                    res.setDeltaComparison(recComparison);
                    mLogger.trace("Before vs after comparison weight: {}", recComparison.getWeight());

                    if (recComparison.getWeight() < mOverlayScoreThreshold) {
                        mLogger.trace("Before vs after comparison weight [{}] less than overlay score threshold [{}]",
                                recComparison.getWeight(), mOverlayScoreThreshold);
                        String notifyTxt = "Overlay comparison score [" +
                                mNumFormat.format(recComparison.getWeight()) +
                                "] less than threshold [" +
                                mNumFormat.format(mOverlayScoreThreshold) + "]";
                        mLogger.trace(notifyTxt);
                        populateTrueResult(res);
                        res.setDescription(notifyTxt);
                    }
                    else {
                        float delta = origWeight.getWeight() - recComparison.getWeight();
                        mLogger.trace("Overlay delta: {}", delta);
                        if (delta > mOverlayDeltaThreshold) {
                            mLogger.trace("Delta {} greater than overlay delta threshold {}", delta, mOverlayDeltaThreshold);
                            String notifyTxt = "Comparison score delta [" +
                                mNumFormat.format(delta) +
                                "] greater than threshold [" +
                                mNumFormat.format(mOverlayDeltaThreshold) + "]";
                            mLogger.debug(notifyTxt);
                            populateTrueResult(res);
                            res.setDescription(notifyTxt);
                        } else {
                            // Custom Enovacom START
                            // Flag as overlay, if
                            // 1. one or more strict traits are changed : DateOfBirth / FamilyName / GivenName / Sex / CommuneCodeOfBirth / FirstNameList / InsNumber
                            // 2. one of the attributes is set to Yes: AttrHomonyme / AttrDouteuse / AttrFictive
                            boolean enovacomOverlay = false;

                            if (isValueChanged(beforeObj, afterObj, "FamilyName")) {
                                String notifyTxt = "Change en nom de naissance";
                                mLogger.debug(notifyTxt);
                                populateTrueResult(res);
                                res.setDescription(notifyTxt);		
                                enovacomOverlay=true;
                            }
                            else if (isValueChanged(beforeObj, afterObj, "GivenName")) {
                                String notifyTxt = "Change en premier prénom";
                                mLogger.debug(notifyTxt);
                                populateTrueResult(res);
                                res.setDescription(notifyTxt);		
                                enovacomOverlay=true;
                            }
                            else if (isValueChanged(beforeObj, afterObj, "Sex")) {
                                String notifyTxt = "Change en sexe";
                                mLogger.debug(notifyTxt);
                                populateTrueResult(res);
                                res.setDescription(notifyTxt);		
                                enovacomOverlay=true;
                            }
                            else if (isValueChanged(beforeObj, afterObj, "CommuneCodeOfBirth")) {
                                String notifyTxt = "Change en code commune de naissance";
                                mLogger.debug(notifyTxt);
                                populateTrueResult(res);
                                res.setDescription(notifyTxt);		
                                enovacomOverlay=true;
                            }
                            else if (isValueChanged(beforeObj, afterObj, "FirstNameList")) {
                                String notifyTxt = "Change en liste des prénoms";
                                mLogger.debug(notifyTxt);
                                populateTrueResult(res);
                                res.setDescription(notifyTxt);		
                                enovacomOverlay=true;
                            }
                            else if (isValueChanged(beforeObj, afterObj, "InsNumber")) {
                                String notifyTxt = "Change en matricule INS";
                                mLogger.debug(notifyTxt);
                                populateTrueResult(res);
                                res.setDescription(notifyTxt);		
                                enovacomOverlay=true;
                            }
                            else if (isValueChanged(beforeObj, afterObj, "DateOfBirth")) {
                                String notifyTxt = "Change en date de naissance";
                                mLogger.debug(notifyTxt);
                                populateTrueResult(res);
                                res.setDescription(notifyTxt);		
                                enovacomOverlay=true;
                            }
                            else if (isAttributeChangedToYes(beforeObj, afterObj, "AttrHomonyme")) {
                                mLogger.trace("Enovacom: AttrHomonyme: {}", afterObj.getObject().getField("AttrHomonyme").getValue());
                                String notifyTxt = "AttrHomonyme est Oui";
                                mLogger.debug(notifyTxt);
                                populateTrueResult(res);
                                res.setDescription(notifyTxt);						
                                enovacomOverlay=true;
                            } 
                            else if (isAttributeChangedToYes(beforeObj, afterObj, "AttrDouteuse")) {
                                mLogger.trace("Enovacom: AttrDouteuse: {}", afterObj.getObject().getField("AttrDouteuse").getValue());
                                String notifyTxt = "AttrDouteuse est Oui";
                                mLogger.debug(notifyTxt);
                                populateTrueResult(res);
                                res.setDescription(notifyTxt);						
                                enovacomOverlay=true;
                            } 
                            else if (isAttributeChangedToYes(beforeObj, afterObj, "AttrFictive")) {
                                mLogger.trace("Enovacom: AttrFictive: {}", afterObj.getObject().getField("AttrFictive").getValue());
                                String notifyTxt = "AttrFictive est Oui";
                                mLogger.debug(notifyTxt);
                                populateTrueResult(res);
                                res.setDescription(notifyTxt);						
                                enovacomOverlay=true;
                            } 
                            if (!enovacomOverlay) {
                            // Custom Enovacom END
                                res.setOverlay(false);
                                if (mLogger.isDebugEnabled()) {
                                    mLogger.trace("Overlay comparison score [" + recComparison.getWeight() + "] and delta [" +
                                        delta + "] within allowable range [" + mOverlayScoreThreshold + "," + 
                                        mOverlayDeltaThreshold + "]");
                                }
                            }
                        }
                    }
                }
            }
        } catch (MatchException | ObjectException e) {
            throw new OverlayDetectorException(e);
        }
        mLogger.debug(res.toString());
        return res;
    }

    @Override
    public boolean isReverted(Connection con, SystemObject afterObj, SystemObject beforeObj, float baseWeight) throws OverlayDetectorException {
        mLogger.debug("Checking [{}] to see if demographics have reverted to demographics from prior overlay using base weight {}",
                afterObj.getSystemObjectPK(), baseWeight);
        mLogger.trace("Current object: {}\nPrior object: {}", afterObj, beforeObj);

        /*
         * Basic algorithm:
         * 1) Compare the record image before the given transaction against the current record
         * 2) If the comparison weight is at least as high as the weight was originally then consider
         *      the record reverted
         */

        try {
            mLogger.debug("Running before vs. after comparison on {}", afterObj.getSystemObjectPK());
            CompositeMatchWeight comparison = mMatch.getWeight(ValueMapUtils.getValueMap(beforeObj.getObject()),
                    ValueMapUtils.getValueMap(afterObj.getObject()));
            mLogger.debug("Before vs. after comparison weight: {}", comparison.getWeight());

            // if EITHER the weight is higher than base weight OR
            // it is less than the base weight but within the delta window
            // then it is considered reverted
            if (comparison.getWeight() >= baseWeight ||
                    baseWeight - comparison.getWeight() <= mOverlayRevertToDelta) {
                return true;
            }
        } catch (MatchException e) {
            throw new OverlayDetectorException(e);
        }

        return false;
    }

    private void populateTrueResult(OverlayDetectorResult res) {
        res.setOverlay(true);
        res.setRejectTransaction(rejectTrans);
        res.setSplitRecord(splitRecord);
        res.setBlockMerge(blockMerge);
        res.setBlockRecalc(blockCalc);
        res.setDeactivateRecord(deactivateRecord);
        res.setQuarantineRecord(quarantineRecord);
    }

    // Don't trigger overlays with certain status changes
    private boolean allowChangeWithoutCheck(SystemObject beforeObj, SystemObject afterObj) {
        // Go through overlay checks if attribute is Y
        if(isAttributeChangedToYes(beforeObj, afterObj, "AttrHomonyme") ||
            isAttributeChangedToYes(beforeObj, afterObj, "AttrDouteuse") ||
            isAttributeChangedToYes(beforeObj, afterObj, "AttrFictive")) {
            return false;
        }
        else if(beforeObj!=null && beforeObj.getObject()!=null && afterObj!=null && afterObj.getObject()!=null
            && beforeObj.getObject().getField("IdentityStatus") != null
            && beforeObj.getObject().getField("IdentityStatus").getValue() != null
            && afterObj.getObject().getField("IdentityStatus") != null
            && afterObj.getObject().getField("IdentityStatus").getValue() != null) {
            String priorStatus = beforeObj.getObject().getField("IdentityStatus").getValue().toString();
            String newStatus = afterObj.getObject().getField("IdentityStatus").getValue().toString();
            if("PROV".equals(priorStatus)) {
                // If prior status was PROV then don't trigger overlay
                return true;
            }
            else if("VALI".equals(priorStatus) && "QUAL".equals(newStatus) && afterObj.getObject().getField("InsNumber") != null && afterObj.getObject().getField("InsNumber").getValue() != null) {
                // If prior status was VALI, target status is QUAL, InsNumber is populated, and FamilyName/GivenName/Sex/InsNumber/DateOfBirth are not changed, allow
                String ins = afterObj.getObject().getField("InsNumber").getValue().toString();
                boolean checkNotAllowedChanges = isValueChanged(beforeObj, afterObj, "FamilyName") ||
                    isValueChanged(beforeObj, afterObj, "GivenName") ||
                    isValueChanged(beforeObj, afterObj, "Sex") ||
                    isValueChanged(beforeObj, afterObj, "InsNumber") ||
                    isValueChanged(beforeObj, afterObj, "DateOfBirth");
                return !ins.isEmpty() && !checkNotAllowedChanges;
            }
            else if("QUAL".equals(priorStatus) && "VALI".equals(newStatus) && (afterObj.getObject().getField("InsNumber") == null || afterObj.getObject().getField("InsNumber").getValue() == null)) {
                // If prior status was QUAL, target status is VAL, InsNumber is was removed, and FamilyName/GivenName/Sex/DateOfBirth/FirstNameList/CommuneCodeOfBirth are not changed, allow
                println("QUAL-VALI")
                boolean checkNotAllowedChanges = isValueChanged(beforeObj, afterObj, "FamilyName") ||
                    isValueChanged(beforeObj, afterObj, "GivenName") ||
                    isValueChanged(beforeObj, afterObj, "Sex") ||
                    isValueChanged(beforeObj, afterObj, "DateOfBirth") ||
                    isValueChanged(beforeObj, afterObj, "FirstNameList") ||
                    isValueChanged(beforeObj, afterObj, "CommuneCodeOfBirth");
                return !checkNotAllowedChanges;
            }
            else {
                return false;
            }
        }
        else {
            return false;
        }
    }

    private boolean isValueChanged(SystemObject beforeObj, SystemObject afterObj, String field) {
        String beforeVal = getStringVal(beforeObj, field);
        String afterVal = getStringVal(afterObj, field);

        // Blank out exclusions
        if(exclusionMap.containsKey(field)) {
            if(beforeVal != null && exclReg.getEntry(exclusionMap.get(field), beforeVal)) {
                beforeVal = null;
            }
            if(afterVal != null && exclReg.getEntry(exclusionMap.get(field), afterVal)) {
                afterVal = null;
            }
        }

        if(beforeVal == null) {
            // Before empty, not considered a change
            return false;
        }
        else if(afterVal == null && beforeVal != null) {
            // After blank, before populated, considered a change
            return true;
        }
        else {
            // Before and after populated, compare
            String afterNoHyphen = afterVal.replaceAll("-", " ");
            String beforeNoHyphen = beforeVal.replaceAll("-", " ");
            String afterNoApos = afterVal.replaceAll("'", " ");
            String beforeNoApos = beforeVal.replaceAll("'", " ");
            return !afterVal.equalsIgnoreCase(beforeVal) && !afterNoHyphen.equalsIgnoreCase(beforeNoHyphen) && !afterNoApos.equalsIgnoreCase(beforeNoApos);
        }
    }

    // Safely get the string value from the system object
    private String getStringVal(SystemObject obj, String field) {
        def val = obj == null ? null :
            obj.getObject() == null ? null :
            obj.getObject().getField(field) == null ? null :
            obj.getObject().getField(field).getValue() == null ? null :
            obj.getObject().getField(field).getValue().toString().isEmpty() ? null :
            obj.getObject().getField(field).getValue();

        if(val instanceof Date) {
            return DateUtils.getParser(DateUtils.DF_YYYYMMDD).format(val);
        }
        else {
            return val == null ? null : val.toString();
        }
    }

    private boolean isAttributeChangedToYes(SystemObject beforeObj, SystemObject afterObj, String field) {
        return afterObj!=null && afterObj.getObject()!=null && 
            (afterObj.getObject().getField(field)!=null && afterObj.getObject().getField(field).getValue()!=null && afterObj.getObject().getField(field).getValue().equalsIgnoreCase("Y")) &&
            (beforeObj.getObject().getField(field)==null || beforeObj.getObject().getField(field).getValue()==null || !beforeObj.getObject().getField(field).getValue().equalsIgnoreCase("Y"));   
    }

    /**
     * 
     * @param engine the engine
     * @param appConfig the application config
     * @throws com.sun.mdm.index.overlay.OverlayDetectorException thrown on error
     */
    @Override
    public void init(Engine engine, ApplicationConfig appConfig) throws OverlayDetectorException {
		
        String action = appConfig.getOverlayAction();
        if (action != null && action.length() > 0) {
            switch (action) {
                case "REJECT":
                        rejectTrans = true;
                        break;
                case "SPLIT":
                        splitRecord = true;
                        break;
                case "UPDATE":
                        // Do nothing
                        break;
                case "UPDATE_BLOCK_CALC":
                        blockCalc = true;
                        blockMerge = true;
                        break;
                case "UPDATE_BLOCK_MERGE":
                        blockMerge = true;
                        blockCalc = false;
                        break;
                case "DEACTIVATE":
                        deactivateRecord = true;
                        break;
                case "QUARANTINE":
                    quarantineRecord = true;
                    break;
                default:
                    throw new OverlayDetectorException("Invalid overlay action [" + action + "].  Allowed " +
                            "values are REJECT, SPLIT, UPDATE, UPDATE_BLOCK_CALC, UPDATE_BLOCK_MERGE, DEACTIVATE, QUARANTINE.");
                }
        }

        exclusionMap.put("FamilyName", "NAME");
        exclusionMap.put("GivenName", "NAME");
        exclusionMap.put("DateOfBirth", "DOB");
        exclusionMap.put("CommuneCodeOfBirth", "BIRTHCOMMUNE");

        try {
            mNumFormat.setMaximumFractionDigits(2);

            mMatch = engine.getMatcher();
            exclReg = engine.getExclusionRegistry();

            mOverlayDeltaThreshold = appConfig.getOverlayDeltaThreshold();
            mOverlayScoreThreshold = appConfig.getOverlayScoreThreshold();
            mOverlayRevertToDelta = appConfig.getOverlayRevertToDelta();
        } catch (Exception e) {
            throw new OverlayDetectorException(e);
        }
    }
}