/*
 Copyright (c) 2016, NextGate Solutions All Rights Reserved.

 This program, and all the NextGate Solutions authored routines referenced herein, 
 are the proprietary properties and trade secrets of NextGate Solutions.

 Except as provided for by license agreement, this program shall not be duplicated, 
 used, reversed engineered, decompiled, disclosed, shared, transferred, placed in a 
 publicly available location (such as but not limited to ftp sites, bit torrents, 
 shared drives, peer to peer networks, and such) without  written consent signed by 
 an officer of NextGate Solutions.

 DISCLAIMER:

 This software is provided as is without warranty of any kind. The entire risk as to 
 the results and performance of this software is assumed by the licensee and/or its 
 affiliates and/or assignees. NextGate Solutions disclaims all warranties, either 
 expressed or implied, including but not limited to the implied warranties of 
 merchantability, fitness for a particular purpose, title and non-infringement, with 
 respect to this software.

 - version control -
 $Id: UserUpdateCallback.groovy 49859 2021-05-27 17:18:49Z david.liechty $
 */
import com.nextgate.mm.common.exceptions.UserException;
import com.sun.mdm.index.objects.EnterpriseObject;
import com.sun.mdm.index.objects.SystemObjectException;
import com.sun.mdm.index.objects.exception.ObjectException;
import com.sun.mdm.index.update.callback.EnterpriseUpdateCallback;
import com.sun.mdm.index.update.callback.EnterpriseUpdateCallbackContext;
import org.slf4j.Logger
import org.slf4j.LoggerFactory

public class UserUpdateCallback implements EnterpriseUpdateCallback {
    private static final Logger LOG = LoggerFactory.getLogger(UserUpdateCallback.class);

	public UserUpdateCallback() {
	}

	public void applyCallback(EnterpriseUpdateCallbackContext context)
	throws SystemObjectException, ObjectException, UserException {

		EnterpriseObject beforeEO = context.getBeforeUpdateEO();
		EnterpriseObject afterEO = context.getAfterUpdateEO();

		DeathIndicatorHelper.validateDeathIndicator(afterEO);

		CustomFieldHandler.processFields(afterEO);

		String comment = context.getCaller().getCommentCode()
		if (comment != null && !comment.isEmpty()) {
			String commentSystem = context.getTransactionSystemCode();
			String commentLid = context.getTransactionLocalId();
			if (commentSystem != null) {
				context.addCommentSO(afterEO.getSystemObject(commentSystem, commentLid), comment);
			} else {
				context.addCommentSBR(afterEO, comment);
			}
		}

		AliasHelper.addSONamesAsSBRAliasesIfDifferent(afterEO, context);

		// Enovacom custom START
		// Fields updated by value of field IdentityStatus: 
		// DateOfBirth/ FamilyName/ GivenName/ Sex/ CommuneCodeOfBirth/ FirstNameList/ InsNumber/ FamilyName2/ GivenName2
		// Hierarchy : QUAL prevails over VALI which itself prevails over PROV.
		//
		// beforeEO IdentityStatus/current		QUAL			VALI			PROV			null
		// AfterEO IdentityStatus/ from update			
		// 								QUAL	no change		no change		no change		no change
		// 								VALI	change AfterEO	no change		no change		no change
		// 								PROV	change AfterEO	change AfterEO	no change		no change
		// 								null	change AfterEO	change AfterEO	change AfterEO	no change

		
		/*LOG.trace("[UserUpdateCallback IN beforeEO IdentityStatus="+beforeEO.getSBR().getObject().getValue("IdentityStatus"));
		LOG.trace("[UserUpdateCallback IN afterEO IdentityStatus="+afterEO.getSBR().getObject().getValue("IdentityStatus"));

        if (beforeEO.getSBR().getObject().getValue("IdentityStatus")!=null &&
		    (afterEO.getSBR().getObject().getValue("IdentityStatus")==null ||
			 ((beforeEO.getSBR().getObject().getValue("IdentityStatus").equals("QUAL"))&&(afterEO.getSBR().getObject().getValue("IdentityStatus").equals("VALI"))) ||
		     ((beforeEO.getSBR().getObject().getValue("IdentityStatus").equals("QUAL"))&&(afterEO.getSBR().getObject().getValue("IdentityStatus").equals("PROV"))) ||
			 ((beforeEO.getSBR().getObject().getValue("IdentityStatus").equals("VALI"))&&(afterEO.getSBR().getObject().getValue("IdentityStatus").equals("PROV"))))) {
			 
			// DateOfBirth/ FamilyName/ GivenName/ Sex/ CommuneCodeOfBirth/ FirstNameList/ InsNumber/ FamilyName2/ GivenName2
			if (beforeEO.getSBR().getObject().getValue("IdentityStatus")!=null) {
				afterEO.getSBR().getObject().setValue("IdentityStatus",beforeEO.getSBR().getObject().getValue("IdentityStatus"));
   			}
			if (beforeEO.getSBR().getObject().getValue("DateOfBirth")!=null) {
				afterEO.getSBR().getObject().setValue("DateOfBirth",beforeEO.getSBR().getObject().getValue("DateOfBirth"));
   			}
			if (beforeEO.getSBR().getObject().getValue("FamilyName")!=null) {
				afterEO.getSBR().getObject().setValue("FamilyName",beforeEO.getSBR().getObject().getValue("FamilyName"));
   			}
			if (beforeEO.getSBR().getObject().getValue("GivenName")!=null) {
				afterEO.getSBR().getObject().setValue("GivenName",beforeEO.getSBR().getObject().getValue("GivenName"));
   			}
			if (beforeEO.getSBR().getObject().getValue("Sex")!=null) {
				afterEO.getSBR().getObject().setValue("Sex",beforeEO.getSBR().getObject().getValue("Sex"));
   			}
			if (beforeEO.getSBR().getObject().getValue("CommuneCodeOfBirth")!=null) {
				afterEO.getSBR().getObject().setValue("CommuneCodeOfBirth",beforeEO.getSBR().getObject().getValue("CommuneCodeOfBirth"));
   			}
			if (beforeEO.getSBR().getObject().getValue("InsNumber")!=null) {
				afterEO.getSBR().getObject().setValue("InsNumber",beforeEO.getSBR().getObject().getValue("InsNumber"));
   			}
			if (beforeEO.getSBR().getObject().getValue("FamilyName2")!=null) {
				afterEO.getSBR().getObject().setValue("FamilyName2",beforeEO.getSBR().getObject().getValue("FamilyName2"));
   			}
			if (beforeEO.getSBR().getObject().getValue("GivenName2")!=null) {
				afterEO.getSBR().getObject().setValue("GivenName2",beforeEO.getSBR().getObject().getValue("GivenName2"));
   			}
		}

		LOG.trace("[UserUpdateCallback OUT afterEO IdentityStatus="+afterEO.getSBR().getObject().getValue("IdentityStatus"));
		LOG.trace("[UserUpdateCallback OUT afterEO DateOfBirth="+afterEO.getSBR().getObject().getValue("DateOfBirth"));
		LOG.trace("[UserUpdateCallback OUT afterEO FamilyName="+afterEO.getSBR().getObject().getValue("FamilyName"));
		LOG.trace("[UserUpdateCallback OUT afterEO GivenName="+afterEO.getSBR().getObject().getValue("GivenName"));
		LOG.trace("[UserUpdateCallback OUT afterEO Sex="+afterEO.getSBR().getObject().getValue("Sex"));
		LOG.trace("[UserUpdateCallback OUT afterEO CommuneCodeOfBirth="+afterEO.getSBR().getObject().getValue("CommuneCodeOfBirth"));
		LOG.trace("[UserUpdateCallback OUT afterEO InsNumber="+afterEO.getSBR().getObject().getValue("InsNumber"));
		LOG.trace("[UserUpdateCallback OUT afterEO FamilyName2="+afterEO.getSBR().getObject().getValue("FamilyName2"));
		LOG.trace("[UserUpdateCallback OUT afterEO GivenName2="+afterEO.getSBR().getObject().getValue("GivenName2"));
		*/
		// Enovacom custom END


		//*******************************************************************
		// MS: Auto-Gen Comments : Activate/Deactivate
		//*******************************************************************
		context.addCommentRecordStatus(beforeEO, afterEO, " was Activated by USER=", " was Deactivated by USER=");

		//**************************************************************
		// MS: Auto-Gen Comments : Split
		//**************************************************************
		context.addCommentRecordSplit(beforeEO, afterEO, " was Split by USER=");




}
}
