import com.sun.mdm.index.objects.metadata.ObjectDefinition;
import com.sun.mdm.index.survivor.StrategyCreationException;
import com.sun.mdm.index.survivor.StrategyParameter;
import com.sun.mdm.index.survivor.SurvivorCalculationContext;
import com.sun.mdm.index.survivor.SurvivorCalculationException;
import com.sun.mdm.index.survivor.SurvivorExclusionHandler;
import com.sun.mdm.index.survivor.SurvivorFuncInitContext;
import com.sun.mdm.index.survivor.SurvivorStrategyInterface;
import com.sun.mdm.index.survivor.SystemField;
import com.sun.mdm.index.survivor.SystemFieldList;
import com.sun.mdm.index.survivor.SystemFieldListMap;
import com.sun.mdm.index.survivor.SystemFieldListMap.SystemKey;
import java.util.Collection;
import java.util.Date;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
/**
 * Custom SBR survivor strategy that uses a prioritized list of field values to determine which value should populate the SBR.
 * Prioritization can be based on a field other than the candidate field itself.
 * @author Amy Lee, Justin Cozzens
 */
public class PrioritizedSurvivorStrategy implements SurvivorStrategyInterface {

	 private static final transient Logger mLogger = LoggerFactory.getLogger(SurvivorStrategyInterface.class);
	private static final String PRIORITY_VALUE = "PRIORITY_VALUE";
	private static final String PRIORITY_FIELD = "PRIORITY_FIELD";
	private static final String LAST_MODIFIED = "LastModified";
	
	private List<String> priorityValues = new ArrayList<String>();
	private String priorityFieldName = null;

    private SurvivorExclusionHandler mSurvivorExclusionHandler;
    
    /** 
	 * Returns a clone of the object.
     * @return cloned object
     * @throws CloneNotSupportedException cloning not supported
     */
    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
    
	/**
	 * Selects the SBR value for the specified field.
	 * 
	 * @param candidateId The name of the field being calculated (e.g. Person.SSNVerifySource).
	 * @param fields the map containing the list of system field for each system record.
	 * @return the system field containing the value to be used in the SBR for given
	 * candidate Id.
	 * @throws SurvivorCalculationException if an exception occurs.
	 */
    public SystemField selectField(SurvivorCalculationContext context) 
            throws SurvivorCalculationException {
		
        SystemFieldListMap fields = context.getSystemFieldListMap();
        String candidateId = context.getCandidateId();

		if (mLogger.isDebugEnabled()) {
			mLogger.debug("Selecting " + candidateId + " field survivor based on priority.");
		}
	
		SystemField fieldValue = null;
		int priority = Integer.MAX_VALUE;
		long lastModified = 0;
		String priorityFieldLocal = priorityFieldName == null ? candidateId : priorityFieldName;
		
		for (SystemKey key : fields.keySet()) {
			SystemFieldList systemFieldList = fields.get(key);
			// Get the value of the priority field, the candidate value, and the last modified date
			SystemField valueField = systemFieldList.get(candidateId);
			String priValue = (String) getCandidateValue(priorityFieldLocal, systemFieldList);
			Object value = getCandidateValue(candidateId, systemFieldList);
			Date lastModifiedDate = (Date) getCandidateValue(LAST_MODIFIED, systemFieldList);
			
			if (lastModifiedDate == null) {
                throw new SurvivorCalculationException("SUR528: Last modified date does not exist in actual field values for candidateID=" + candidateId + ",systemKey=" + key);
            }
			
			if (mLogger.isDebugEnabled()) {
				mLogger.debug("Evaluating " + candidateId + " for systemKey " + key + " with priValue=" + priValue + ",value=" + value);
			}
			
			if (value != null) {
                if(!mSurvivorExclusionHandler.isExcluded(candidateId, value)) {
					// Lookup priority value in priority list
					int pri = priorityValues.indexOf(priValue);
					if(pri > -1) {
						// Priority value in list, if higher priority then current value or same priority and more recent, use it
						if(pri < priority || (pri == priority && lastModifiedDate.getTime() > lastModified)) {
							priority = pri;
							fieldValue = valueField;
							lastModified = lastModifiedDate.getTime();
							if (mLogger.isDebugEnabled()) {
								mLogger.debug("Potential SBR value for " + candidateId + " for systemKey " + key + " priority=" + pri);
							}
						}
					}
					else if(pri == -1 && priority == Integer.MAX_VALUE && lastModifiedDate.getTime() > lastModified) {
						// Not in the priority list and no priority entry has been found and this entry is more recent, use it
						fieldValue = valueField;
						lastModified = lastModifiedDate.getTime();
					}
                }
			}
		}
		return fieldValue;
    }

	/**
	 * Initializes PrioritizedSurvivorStrategy. Takes two parameters:<br/><br/>
	 *
	 * <b>PRIORITY_VALUE</b> - Multiple entries with this name, identifies the priority order
	 * of values, in order of highest priority first.<br/>
	 * <b>PRIORITY_FIELD</b> - Identifies the field used for identifying the priority of
	 * the candidate field. Default: the candidate field itself<br/>
	 * 
	 * @param parameters The list SBR parameters from MM_CFG_SBR_FUNC_PARAMS.
	 * @param survivorExclusionHandler Survivor Exclusion Handler.
	 * @param objDef Object Definition.
	 * @throws StrategyCreationException if an exception occurs.
	 */
    public void init(SurvivorFuncInitContext context) throws StrategyCreationException {
        Collection<StrategyParameter> parameters = context.getParameters();
        
        mSurvivorExclusionHandler = context.getSurvivorExclusionHandler();
        
		if (parameters != null) {
            for (StrategyParameter param : parameters) {
                if (PRIORITY_VALUE.equals(param.getName())) {
                    priorityValues.add(param.getValue());
					mLogger.debug("Setting Priority Field Name to " + priorityFieldName);
                }
                else if (PRIORITY_FIELD.equals(param.getName())) {
                    priorityFieldName = param.getValue();
					mLogger.debug("Setting Priority Field Name to " + priorityFieldName);
                }
            }
        }
		if(priorityValues.isEmpty()) {
			throw(new StrategyCreationException("Unable to create survivor strategy: no priority values are set"));
		}
    }
    
	/** 
	 * Returns the value for the specified candidate field name from a list of system fields
     * @param fieldName field name
     * @param systemFields SystemFieldList of fields
     * @return field value
     */
    private Object getCandidateValue(String fieldName, SystemFieldList systemFields) {
        SystemField f = systemFields.get(fieldName);
        return (f == null) ? null : f.getValue();
    }
}
