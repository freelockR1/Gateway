/*
    Copyright (c) 2016, NextGate Solutions All Rights Reserved.

    This program, and all the NextGate Solutions authored routines referenced herein,
    are the proprietary properties and trade secrets of NextGate Solutions.

    Except as provided for by license agreement, this program shall not be duplicated,
    used, reversed engineered, decompiled, disclosed, shared, transferred, placed in a
    publicly available location (such as but not limited to ftp sites, bit torrents,
    shared drives, peer to peer networks, and such) without  written consent signed by
    an officer of NextGate Solutions.

    DISCLAIMER:

    This software is provided as is without warranty of any kind. The entire risk as to
    the results and performance of this software is assumed by the licensee and/or its
    affiliates and/or assignees. NextGate Solutions disclaims all warranties, either
    expressed or implied, including but not limited to the implied warranties of
    merchantability, fitness for a particular purpose, title and non-infringement, with
    respect to this software.

    - version control -
    $Id: AliasContainer.groovy 22865 2016-07-01 17:03:04Z samuel.levin $
 */
import com.sun.mdm.index.objects.ObjectField;
import com.sun.mdm.index.objects.ObjectNode;
import com.sun.mdm.index.objects.exception.ObjectException;

/**
 * A container for aliases that implements hashCode and equals methods
 */
public  class AliasContainer {
    
    private final ObjectNode mAlias;
    private final String mGivenName;
    private final String mFamilyName;
    private final String mSecondName;
    private final String mFirstNameList;
    
    /**
     * Constructor
     * @param obj alias object
     */
    public AliasContainer(ObjectNode obj) throws ObjectException {
        mAlias = obj;
        mGivenName = getValue(obj, AliasFields.getGivenName());
        mFamilyName = getValue(obj, AliasFields.getFamilyName());
        mSecondName = getValue(obj, AliasFields.getSecondName());
        mFirstNameList = getValue(obj, AliasFields.getFirstNameList());
    }
    
    /**
     * Create an alias object from Person-level name fields. For example, if a person's
     * name changed, this method can create an alias object from the person's prior
     * primary name fields
     * @param person
     * @return 
     */
    public static AliasContainer createAliasFromPersonFields(ObjectNode person) {
        
        try {
            ObjectNode alias = (ObjectNode) Class.forName("com.nextgate.mm.index.objects.person.AliasObject").newInstance();
            
            for (String field : AliasFields.getPersonNameFieldList()) {
                
                setValue(alias, field, readName(person.getValue(field)));
            }
            
            AliasContainer ret = new AliasContainer(alias);
            
            return ret;
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | ObjectException ex) {
            throw new ObjectException(ex);
        }
    }
    
    
    /**
     * Hashcode of first, last and middle names
     * @return hash code
     */
    @Override
    public int hashCode() {
        int hash = 7;
        hash = 29 * hash + (this.mGivenName!= null ? this.mGivenName.hashCode() : 0);
        hash = 29 * hash + (this.mFamilyName!= null ? this.mFamilyName.hashCode() : 0);
        
        ObjectField sn = this.mAlias.getField(AliasFields.getSecondName());
        if (sn != null && sn.isKeyType()) {
            hash = 29 * hash + (this.mSecondName!= null ? this.mSecondName.hashCode() : 0);
        }
        ObjectField fnl = this.mAlias.getField(AliasFields.getFirstNameList());
        if (sn != null && sn.isKeyType()) {
            hash = 29 * hash + (this.mFirstNameList!= null ? this.mFirstNameList.hashCode() : 0);
        }
        return hash;
    }
    
    /**
     * return true if equals
     * @param obj other alias
     * @return true if equals
     */
    @Override
    public boolean equals(Object obj) {
        
        return obj != null && obj instanceof AliasContainer && ((AliasContainer) obj).hashCode() == this.hashCode();
    }
    
    @Override
    public String toString() {
        StringBuilder ret = new StringBuilder();
        
        ret.append("Alias: [Given: ").append(mGivenName).append(", Second: ")
                .append(mSecondName).append(", Family: ").append(mFamilyName)
                .append(", FirstNameList: ").append(mFirstNameList)
                .append("]");
        
        return ret.toString();
    }
    
    /**
     * Get alias
     * @return alias
     */
    public ObjectNode getAlias() {
        return mAlias;
    }
    
    //
    // Static utilities
    //
    
    private static String getValue(ObjectNode obj, String fieldName) throws ObjectException {
        String s = (String) obj.getValue(fieldName);
        if (s != null) {
            s = s.toUpperCase().trim();
        }
        return s;
    }

    private static void setValue(ObjectNode obj, String fieldName, String value) throws ObjectException {
        if (value != null) {
            value = value.toUpperCase().trim();
        }
        obj.setValue(fieldName, value);
    }
    
    private static String readName(Object name) {
        if (name == null) {
            return null;
        } else {
            String s = (String) name;
            return s.replace('"', '\''); //'
        }
    }
    
    
}
