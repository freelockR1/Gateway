NextGate Solutions

Modifying Workflow Security Scripts Readme

NOTE: Before using this information and the product it supports, read the information in
the Notices section at the end of this document.

===============================================================================================
Table of Contents
===============================================================================================

    A.   Introduction
    B.   Creating New Scripts for Onboardings
    C.   Adding/Removing Health Service
    D.   Notices

===============================================================================================
A. Introduction
===============================================================================================
The following security scripts have been created to control access to specified health services
within Workflow. These scripts are referenced when accessing the Task Manager UI. MatchMetrix
related scripts are located in etc/nextgate/mm/groovy/.

    CrossSystemOnlyLabel.groovy : 
        Security script which defines access to Cross System tasks.
    
    TemplateSingleOnlyLabel.groovy : 
        Security scripts template which defines a single health service to allow access to. 
        Health services not defined in this script will be restricted.
        Example: AHSOnlyLabel.groovy
        
    TemplateMultiLabel.groovy :
        Security script template which defines a list of health services to allow access to. 
        Health services not defined in the list will be restricted. As of Cohort 2 onbooarding,
        no users have access to multiple health service tasks. This template is available should
        the use case become neccessary.

Note: 
Adding new scripts do not require NGS to be restarted. Modifiying existing scripts do require 
NGS to be restarted.

===============================================================================================
B. Creating New Scripts for Onboardings
===============================================================================================

    Onboarding health services as part of Cohort X requires new access and permissions to
    be defined for each health service or group of health services. New groups and roles should
    be created in Access Manager, which will then reference these groovy scripts. Instructions
    on how to create groups/roles and configuring groovy scripts are available in :
    NextGate Access Manager User Guide.pdf.
        o Chapter 5 : Managing Roles and Permissions
            o Section 5.2 : Creating Roles
            o Section 5.3 : Using Groovy Scripts to Configure Permissions
        o Chapter 6 : Managing Groups
        
    Configuring Access to a Health Service :
        1. Duplicate TemplateSingleOnlyLabel.groovy
        2. Rename the duplicated copy to specify which health service it will be for.
            o Example: Onboarding Monash Health, the script will be named MSHOnlyLabel.groovy
        3. Open MSHOnlyLabel.groovy in a text editor
        4. Find references to TemplateSingleOnlyLabel and replace with MSHOnlyLabel. There 
        should only be 2 references.
        5. Locate the List<String> variable : LABELS
        6. Modify LABELS variable to specify numeric code for Monash instead of "HS code".
            o private static final List<String> LABELS = Arrays.asList("1170");
        7. Modify the comments to specify what the script provides access for
        8. Save the file
        
    Configuring Access to a List of Health Services :
        1. Duplicate TemplateMultiLabel.groovy
        2. Rename the duplicated copy to specify which group it will be for.
            o Example: Onboarding cohort X, the script will be named CohortXMultiLabel.groovy
        3. Open CohortXMultiLabel.groovy in a text editor
        4. Find references to TemplateMultiLabel and replace with CohortXMultiLabel. There should
        only be 2 references.
        5. Locate the List<String> variable : LABELS
        6. Modify LABELS variable to specify the new list of numeric codes for Cohort X.
            o Example: Cohort X includes Bendingo Health, Melbourne Health, and Eastern Health.
                o private static final List<String> LABELS = Arrays.asList("1021", "1334", "1050");
        7. Modify the comments to specify what the script provides access for
        8. Save the file

===============================================================================================
C. Adding/Removing Health Service
===============================================================================================

    Adding a Health Service(s) :
        1. Open CohortXMultiLabel.groovy in a text editor
        2. Locate the List<String> variable : LABELS
        3. Add the new health service numeric code to LABELS.
            o Example: add Monash Health (1170) to CohortXMultiLabel.groovy
                Current LABELS = Arrays.asList("1021", "1334", "1050");
                Updated LABELS = Arrays.asList("1021", "1334", "1050", "1170");
            Note: it is possible to add more than one health service at a time.
        4. Modify the comments to specify what the script provides access for
        5. Save the file
        6. Restart NGS
        
    Removing Health Service(s) :
        1. Open CohortXMultiLabel.groovy in a text editor
        2. Locate the List<String> variable : LABELS
        3. Remove the health services(s) numeric code from LABELS
            o Example: remove Bendingo Health (1021) from CohortXMultiLabel.groovy
                Current LABELS = Arrays.asList("1021", "1334", "1050");
                Updated LABELS = Arrays.asList("1334", "1050");
            Note: it is possible to remove more than one health service at a time.
        4. Modify the comments to specify what the script provides access for
        5. Save the file
        6. Restart NGS

===============================================================================================
D. Notices
===============================================================================================

This program, and all the NextGate Solutions authored routines referenced herein,
are the proprietary properties and trade secrets of NextGate Solutions.

Except as provided for by license agreement, this program shall not be duplicated,
used, reversed engineered, decompiled, disclosed, shared, transferred, placed in a
publicly available location (such as but not limited to ftp sites, bit torrents,
shared drives, peer to peer networks, and such) without  written consent signed by
an officer of NextGate Solutions.

DISCLAIMER:

This software is provided as is without warranty of any kind. The entire risk as to
the results and performance of this software is assumed by the licensee and/or its
affiliates and/or assignees. NextGate Solutions disclaims all warranties, either
expressed or implied, including but not limited to the implied warranties of
merchantability, fitness for a particular purpose, title and non-infringement, with
respect to this software.

(C) Copyright 2019, NextGate Solutions All Rights Reserved.