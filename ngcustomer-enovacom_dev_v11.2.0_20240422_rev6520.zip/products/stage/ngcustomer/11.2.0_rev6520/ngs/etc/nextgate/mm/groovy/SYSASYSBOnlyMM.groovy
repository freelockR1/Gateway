
/*
    Copyright (c) 2023, NextGate Solutions All Rights Reserved.

    This program, and all the NextGate Solutions authored routines referenced herein, 
    are the proprietary properties and trade secrets of NextGate Solutions.

    Except as provided for by license agreement, this program shall not be duplicated, 
    used, reversed engineered, decompiled, disclosed, shared, transferred, placed in a 
    publicly available location (such as but not limited to ftp sites, bit torrents, 
    shared drives, peer to peer networks, and such) without  written consent signed by 
    an officer of NextGate Solutions.

    DISCLAIMER:

    This software is provided as is without warranty of any kind. The entire risk as to 
    the results and performance of this software is assumed by the licensee and/or its 
    affiliates and/or assignees. NextGate Solutions disclaims all warranties, either 
    expressed or implied, including but not limited to the implied warranties of 
    merchantability, fitness for a particular purpose, title and non-infringement, with 
    respect to this software.
 */

import com.nextgate.interfaces.am.SecurityScript;
import com.sun.mdm.index.master.SystemDefinition;
import com.sun.mdm.index.objects.ObjectField;
import com.sun.mdm.index.objects.EnterpriseObject;
import com.sun.mdm.index.objects.SystemObject;
import com.sun.mdm.index.objects.SBR;
import java.util.Map;
import org.slf4j.Logger
import org.slf4j.LoggerFactory

/**
 * Security script that does not allow access if there is not a record with the specified system code.
 */
public class SYSASYSBOnlyMM implements SecurityScript {
    private static final transient Logger LOG = LoggerFactory.getLogger(SYSASYSBOnlyMM.class);
    private static final List<String> SYSTEMCODES = Arrays.asList("SYS_A", "SYS_B");

    @Override
    public boolean isAccessible(Map<String, Object> context, Object resource, String action) {
 		if (resource instanceof SystemDefinition) {
            SystemDefinition sd = (SystemDefinition) resource;
			
            if (SYSTEMCODES.contains(sd.getSystemCode())) {
                return true;
            }

            return false;
        }

        if ("lookupComments".equals(action)) {
            return true;
        }

        if (resource instanceof SBR) {
            EnterpriseObject entObj = (EnterpriseObject) context.get("eo");

            if (entObj != null) {
                for (SystemObject sysObj : entObj.getSystemObjects()) {
                    // if record does systemcode record, accessible
                    if (SYSTEMCODES.contains(sysObj.getSystemCode())) {
                        return true;
                    }
                }
                return false;
            }
        }
        else if (resource instanceof EnterpriseObject) {
            // filter the EO if systemcode does not contribute
            EnterpriseObject eo = (EnterpriseObject) resource;

            for (SystemObject sysObj : eo.getSystemObjects()) {
                // if record has systemcode record, accessible
                if (SYSTEMCODES.contains(sysObj.getSystemCode())) {
                    return true;
                }
            }
            return false;
        }
        else if (resource instanceof SystemObject) {
            SystemObject sysObj = (SystemObject) resource;

            // if record does has systemcode record, accessible
            if (SYSTEMCODES.contains(sysObj.getSystemCode())) {
                return true;
            }
            return false;
        }
        else {
            EnterpriseObject entObj = (EnterpriseObject) context.get("eo");

            if (entObj != null) {
                for (SystemObject sysObj : entObj.getSystemObjects()) {
                    // if record does systemcode record, accessible
                    if (SYSTEMCODES.contains(sysObj.getSystemCode())) {
                        return true;
                    }
                }
                return false;
            }
        }

        return true;
    }

    @Override
    public String getName() {
        return this.getClass().getName();
    }
}
