/*
  Copyright (c) 2023, NextGate Solutions All Rights Reserved.

  This program, and all the NextGate Solutions authored routines referenced herein,
  are the proprietary properties and trade secrets of NextGate Solutions.

  Except as provided for by license agreement, this program shall not be duplicated,
  used, reversed engineered, decompiled, disclosed, shared, transferred, placed in a
  publicly available location (such as but not limited to ftp sites, bit torrents,
  shared drives, peer to peer networks, and such) without  written consent signed by
  an officer of NextGate Solutions.

  DISCLAIMER:

  This software is provided as is without warranty of any kind. The entire risk as to
  the results and performance of this software is assumed by the licensee and/or its
  affiliates and/or assignees. NextGate Solutions disclaims all warranties, either
  expressed or implied, including but not limited to the implied warranties of
  merchantability, fitness for a particular purpose, title and non-infringement, with
  respect to this software.

  - version control -
  $Id$
*/

import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.camel.Exchange;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nextgate.core.datatypes.CallerContext;
import com.nextgate.core.exceptions.InvalidParameterException;
import com.nextgate.core.exceptions.ResourceUnavailableException;
import com.nextgate.core.utils.DateUtils;
import com.nextgate.core.utils.GeneralString;
import com.nextgate.interfaces.ms.datatypes.ComparisonType;
import com.nextgate.interfaces.ms.datatypes.MMNotificationResponse;
import com.nextgate.interfaces.ms.datatypes.NGMSMessage;
import com.nextgate.interfaces.ms.datatypes.PersonType;
import com.nextgate.interfaces.ms.datatypes.ProviderType;
import com.nextgate.interfaces.ngs.ClusterInterface;
import com.nextgate.interfaces.ngs.LockInterface;
import com.nextgate.interfaces.ngs.datatypes.PersonIdentifierType;
import com.nextgate.interfaces.ngs.enums.RegistryType;
import com.nextgate.interfaces.workflow.api.WorkflowBadRequestException;
import com.nextgate.interfaces.workflow.api.WorkflowForbiddenException;
import com.nextgate.interfaces.workflow.api.WorkflowNotFoundException;
import com.nextgate.interfaces.workflow.api.WorkflowService.WorkflowServiceHelper;
import com.nextgate.interfaces.workflow.api.objects.FormInfo;
import com.nextgate.interfaces.workflow.api.objects.FormInfo.FormProp;
import com.nextgate.interfaces.workflow.api.objects.ProcessInstance;
import com.nextgate.interfaces.workflow.api.objects.Task;
import com.nextgate.interfaces.workflow.api.objects.TasksRequest;
import com.nextgate.interfaces.workflow.api.objects.TasksResponse;
import com.nextgate.mm.index.master.MasterController;
import com.nextgate.ms.component.adapter.sender.workflow.WorkflowConstants;
import com.nextgate.ms.component.adapter.sender.workflow.WorkflowSenderFactory;
import com.nextgate.ms.component.adapter.sender.workflow.interfaces.AssumedMatchContext;
import com.nextgate.ms.component.adapter.sender.workflow.interfaces.AssumedMatchTaskGenerator;
import com.nextgate.ms.component.adapter.sender.workflow.interfaces.MergeCompleteContext;
import com.nextgate.ms.component.adapter.sender.workflow.interfaces.MergeCompleteTaskGenerator;
import com.nextgate.ms.component.adapter.sender.workflow.interfaces.PotentialDuplicateContext;
import com.nextgate.ms.component.adapter.sender.workflow.interfaces.PotentialDuplicateTaskGenerator;
import com.nextgate.ms.component.adapter.sender.workflow.interfaces.PotentialMatchContext;
import com.nextgate.ms.component.adapter.sender.workflow.interfaces.PotentialMatchTaskGenerator;
import com.nextgate.ms.component.adapter.sender.workflow.interfaces.PotentialOverlayContext;
import com.nextgate.ms.component.adapter.sender.workflow.interfaces.PotentialOverlayTaskGenerator;
import com.nextgate.ms.component.adapter.sender.workflow.interfaces.WorkflowTask;
import com.nextgate.ms.component.adapter.sender.workflow.processors.WorkflowUpdateContext;
import com.nextgate.ms.component.adapter.sender.workflow.routes.Activator;
import com.nextgate.ms.component.adapter.sender.workflow.settings.WorkflowSenderInstanceGroup;
import com.nextgate.ms.component.adapter.sender.workflow.utils.ValueListUtils;
import com.nextgate.ms.component.adapter.sender.workflow.utils.WorkflowHelper;
import com.nextgate.ms.configmanager.cache.ConfigurationCacheEntry;
import com.sun.mdm.index.master.CallerInfo;
import com.sun.mdm.index.master.search.transaction.TransactionSummary;
import com.sun.mdm.index.objects.EnterpriseObject;
import com.sun.mdm.index.objects.MarkedUnique;
import com.sun.mdm.index.objects.SBR;
import com.sun.mdm.index.objects.SystemObject;
import com.sun.mdm.index.objects.SystemObjectPK;


/**
 * The default MM Notification Workflow Processors.
 *
 * @author Peter Berkman (peter@nextgate.com)
 * @version $Revision$
 * @since 10.0.0
 */
public class DefaultNotificationProcessors {

    private static final Logger LOG = LoggerFactory.getLogger(DefaultNotificationProcessors.class);

    private static final String P_PROPS = "Props ";
    private static final String P_TASKPROPS = "Task Props ";
    private static final String EUIDS_LOG = "], EUIDs: [{}] [{}]";
    private static final String WEIGHT = "weight";
    private static final String IDS = "ids";
    private static final String PROPERTIES = "properties";
    private static final String PROCESS_INSTANCE = "PROCESSINSTANCE";

    /**
     * The default constructor.
     */
    public DefaultNotificationProcessors() {

        // nothing yet.
    }

    /**
     * Start merge complete.
     *
     * @param conf the configuration entry
     * @param exch the exchange
     * @param msMsg the ngms message
     * @param req the MM notification request
     * @throws Exception on error
     */
    public void startMergeComplete(final ConfigurationCacheEntry conf, final Exchange exch, final NGMSMessage msMsg, final MMNotificationResponse req) throws Exception {

        LOG.trace("[begin] wfStartMergeComplete: {}", msMsg);

        final WorkflowSenderInstanceGroup wsig = (WorkflowSenderInstanceGroup) conf.getComponentInstanceSettings();

        if (GeneralString.trimString(wsig.getTaskScriptMergeComplete()) == null) {

            LOG.debug("[end] wfStartMergeComplete NO TASK SCRIPT CONFIGURED: {}", msMsg);

            return;
        }

        if (msMsg.countCanonicalData() < 1) {

            LOG.debug("[end] wfStartMergeComplete no person or provider data mapped in request: ", msMsg);

            return;
        }

        final Map<String, Object> taskProps = new HashMap<String, Object>();

        if (req.getRegistry() == RegistryType.PERSON) {

            final PersonType person = msMsg.getCanonicalData().get(0).getPerson();
            final PersonType priorPerson = msMsg.getCanonicalData().get(0).getPriorPerson();

            ValueListUtils.add(taskProps, WorkflowConstants.T_SURVIVINGEUID, person.getEuid().getId());
            ValueListUtils.add(taskProps, WorkflowConstants.T_MERGEDEUID, priorPerson.getEuid().getId());

            if ((priorPerson != null) && (priorPerson.countPersonIds() > 0)) {

                final StringBuilder sb = new StringBuilder();

                for (final PersonIdentifierType pit : priorPerson.getPersonIds()) {

                    if (sb.length() > 0) {

                        sb.append("|");
                    }

                    sb.append(pit.getAssigningAuthority().getAuthorityNameString()).append("/").append(pit.getId());
                }

                ValueListUtils.add(taskProps, WorkflowConstants.T_MERGEDLIDS, sb.toString());
            }
        }
        else {
            final ProviderType provider = msMsg.getCanonicalData().get(0).getProvider();
            final ProviderType priorProvider = msMsg.getCanonicalData().get(0).getPriorProvider();

            ValueListUtils.add(taskProps, WorkflowConstants.T_SURVIVINGEUID, provider.getEuid().getId());
            ValueListUtils.add(taskProps, WorkflowConstants.T_MERGEDEUID, priorProvider.getEuid().getId());

            if (priorProvider.countIdentifiers() > 0) {

                final StringBuilder sb = new StringBuilder();

                for (final PersonIdentifierType pit : priorProvider.getLocalIds()) {

                    if (sb.length() > 0) {

                        sb.append("|");
                    }

                    sb.append(pit.getAssigningAuthority().getAuthorityNameString()).append("/").append(pit.getId());
                }

                ValueListUtils.add(taskProps, WorkflowConstants.T_MERGEDLIDS, sb.toString());
            }
        }

        final CallerContext cc = msMsg.getAuthority().toCallerContext();

        final MergeCompleteTaskGenerator taskGenerator = (MergeCompleteTaskGenerator) WorkflowSenderFactory.getGroovyLoader(wsig).newInstance(wsig.getTaskScriptMergeComplete());
        final MergeCompleteContext context = new MergeCompleteContext();

        context.setExchange(exch);
        context.setMessage(msMsg);
        context.setNotification(req);

        final WorkflowTask task = taskGenerator.generateTask(context);

        taskProps.putAll(task.getVariables());

        ValueListUtils.toTraceLog(LOG, P_TASKPROPS, taskProps);

        WorkflowServiceHelper.getService(Activator.getBC()).createProcessInstanceByKey(cc, WorkflowHelper.getInstance().getProcessDefinitionKey(wsig, WorkflowConstants.T_MERGECOMPLETEPROCESS), null,
            task.getSummaryText(), convertProperties(taskProps), null, task.getLabels(), task.getSecurityLabels());

        LOG.trace("[end] wfStartMergeComplete: {}", msMsg);
    }

    /**
     * Start potential overlay.
     *
     * @param conf the configuration entry
     * @param exch the exchange
     * @param msMsg the ngms message
     * @param req the mm notification request
     * @throws Exception on error
     */
    public void startPotentialOverlay(final ConfigurationCacheEntry conf, final Exchange exch, final NGMSMessage msMsg, final MMNotificationResponse req) throws Exception {

        LOG.trace("[begin] wfStartPotentialOverlay: {}", msMsg);

        final WorkflowSenderInstanceGroup wsig = (WorkflowSenderInstanceGroup) conf.getComponentInstanceSettings();

        if (GeneralString.trimString(wsig.getTaskScriptPotentialOverlay()) == null) {

            LOG.debug("[end] wfStartPotentialOverlay NO TASK SCRIPT CONFIGURED: {}", msMsg);
            return;
        }

        final CallerContext cc = msMsg.getAuthority().toCallerContext();

        final PotentialOverlayTaskGenerator taskGenerator = (PotentialOverlayTaskGenerator) WorkflowSenderFactory.getGroovyLoader(wsig).newInstance(wsig.getTaskScriptPotentialOverlay());
        final PotentialOverlayContext context = new PotentialOverlayContext();
        context.setExchange(exch);
        context.setMessage(msMsg);
        context.setNotification(req);

        final WorkflowTask task = taskGenerator.generateTask(context);

        final Map<String, Object> taskProps = new HashMap<String, Object>();
        taskProps.putAll(task.getFormProperties());

        WorkflowServiceHelper.getService(Activator.getBC()).createProcessInstanceByKey(cc, WorkflowHelper.getInstance().getProcessDefinitionKey(wsig, WorkflowConstants.T_POTENTIALOVERLAYPROCESS), null,
            task.getSummaryText(), convertProperties(taskProps), null, task.getLabels(), task.getSecurityLabels());

        LOG.trace("[end] wfStartPotentialOverlay: {}", msMsg);
    }

    /**
     * Start potential duplicate.
     *
     * @param conf the configuration entry
     * @param exch the exchange
     * @param msMsg the ngms message
     * @param req the mm notification request
     * @param compt the comparisons
     * @throws Exception on error
     */
    public void startPotentialDuplicate(final ConfigurationCacheEntry conf, final Exchange exch, final NGMSMessage msMsg,
        final MMNotificationResponse req, final ComparisonType compt) throws Exception {

        LOG.trace("[begin] wfStartPotentialDuplicate: {}", msMsg);

        final WorkflowSenderInstanceGroup wsig = (WorkflowSenderInstanceGroup) conf.getComponentInstanceSettings();

        final String taskScript = GeneralString.trimString(wsig.getTaskScriptPotentialDup());

        if (taskScript == null) {

            LOG.trace("[end] wfStartPotentialDuplicate NO TASK SCRIPT CONFIGURED: {}", msMsg);
            return;
        }

        final WorkflowUpdateContext ctx = new WorkflowUpdateContext();

        ctx.setAppName(wsig.getAppName());
        ctx.setAuditUser(msMsg.getAuthority().getAuditUser());
        ctx.setComparison(compt);
        ctx.setExchange(exch);
        ctx.setMessage(msMsg);
        ctx.setNotification(req);
        ctx.setTenant(msMsg.getAuthority().getTenant());
        ctx.setTransId(msMsg.getMessageControlId());

        final CallerContext caller = new CallerContext();
        caller.setTenant(ctx.getTenant());

        final MasterController mc = WorkflowHelper.getInstance().getMasterController(conf);

        final EnterpriseObject eo1 = mc.getEnterpriseObject(caller, compt.getCompareFrom().getId());
        final EnterpriseObject eo2 = mc.getEnterpriseObject(caller, compt.getCompareTo().getId());

        final List<MarkedUnique> mus = mc.lookupMarkedUniquesForEuids(caller, Long.parseLong(eo1.getEUID()), Long.parseLong(eo2.getEUID()));

        this.startPotentialDuplicate(conf, msMsg, ctx, eo1, eo2, mus, false);

        LOG.trace("[end] wfStartPotentialDuplicate: {}", msMsg);
    }

    /**
     * Start potential duplicate.
     *
     * @param conf the configuration
     * @param msMsg the ngms message
     * @param ctx the workflow context
     * @param eo1 the EO 1
     * @param eo2 the EO 2
     * @param mus the marked uniques for EO 1
     * @param skipChecks skip checks if already created - initial load, etc.
     * @return the list of processing instances
     * @throws Exception on error
     */
    public List<ProcessInstance> startPotentialDuplicate(final ConfigurationCacheEntry conf, final NGMSMessage msMsg, final WorkflowUpdateContext ctx,
        final EnterpriseObject eo1, final EnterpriseObject eo2, final List<MarkedUnique> mus, final boolean skipChecks) throws Exception {

        LOG.trace("[begin] wfStartPotentialDuplicate {}", msMsg);

        final WorkflowSenderInstanceGroup wsig = (WorkflowSenderInstanceGroup) conf.getComponentInstanceSettings();

        final String taskScript = GeneralString.trimString(wsig.getTaskScriptPotentialDup());

        if (taskScript == null) {

            return null;
        }

        final CallerContext cc = msMsg.getAuthority().toCallerContext();

        final List<ProcessInstance> pis = new LinkedList<>();

        if ((eo1 == null) || (eo2 == null)) {

            LOG.trace("[end] wfStartPotentialDuplicate - no EOs found: {}", msMsg);
            return pis;
        }

        for (final SystemObject so1 : eo1.getSystemObjects()) {

            if (!(SystemObject.STATUS_ACTIVE.equals(so1.getStatus()))) {

                continue;
            }

            final String systemCode1 = so1.getSystemCode();

            for (final SystemObject so2 : eo2.getSystemObjects()) {

                if (!(SystemObject.STATUS_ACTIVE.equals(so2.getStatus()))) {

                    continue;
                }

                final String systemCode2 = so2.getSystemCode();

                if (!(systemCode1.equals(systemCode2))) {

                    continue;
                }

                // load-tasks can skip checks for initial loads to improve performance

                if (!skipChecks) {
                    // check to see if already created, needed since this creation is called on updates now

                    final Map<String, Object> props = new HashMap<>();

                    props.put(WorkflowConstants.T_POTENTIALDUPLICATEID, Long.parseLong(ctx.getComparison().getId()));
                    props.put(WorkflowConstants.T_SYS1, systemCode1);
                    props.put(WorkflowConstants.T_LID1, so1.getLID());
                    props.put(WorkflowConstants.T_SYS2, systemCode2);
                    props.put(WorkflowConstants.T_LID2, so2.getLID());

                    List<ProcessInstance> existingPIs = WorkflowServiceHelper.getService(Activator.getBC()).getProcessInstances(cc, null,
                        WorkflowHelper.getInstance().getProcessDefinitionKey(wsig, WorkflowConstants.T_SAMESYSTEMPOTENTIALDUPLICATE), null, props);

                    if (!existingPIs.isEmpty()) {
                        // found a PI, don't recreate
                        continue;
                    }

                    // check the reverse too
                    props.put(WorkflowConstants.T_SYS1, systemCode2);
                    props.put(WorkflowConstants.T_LID1, so2.getLID());
                    props.put(WorkflowConstants.T_SYS2, systemCode1);
                    props.put(WorkflowConstants.T_LID2, so1.getLID());

                    existingPIs = WorkflowServiceHelper.getService(Activator.getBC()).getProcessInstances(cc, null,
                        WorkflowHelper.getInstance().getProcessDefinitionKey(wsig, WorkflowConstants.T_SAMESYSTEMPOTENTIALDUPLICATE), null, props);

                    if (!existingPIs.isEmpty()) {
                        // found a PI, don't recreate
                        continue;
                    }

                    // only create pot-dups if there is not a marked unique between them

                    final String lid1 = so1.getLID();
                    final String lid2 = so2.getLID();

                    if (this.isLidsMarkedUnique(mus, so1.getSystemCode(), so1.getLID(), so2.getSystemCode(), so2.getLID())) {
                        LOG.debug("Marked unique found for {}/{} and {}/{}, skipping process instance creation", systemCode1, lid1, systemCode2, lid2);
                        continue;
                    }
                }

                final PotentialDuplicateTaskGenerator taskGenerator = (PotentialDuplicateTaskGenerator) WorkflowSenderFactory.getGroovyLoader(wsig).newInstance(taskScript);
                final PotentialDuplicateContext context = new PotentialDuplicateContext();

                context.setExchange(ctx.getExchange());
                context.setMessage(ctx.getMessage());
                context.setNotification(ctx.getNotification());
                // RESEARCH: what if there are more than one system object per EUID?
                context.setEUID1(ctx.getComparison().getCompareFrom().getId());
                context.setEUID2(ctx.getComparison().getCompareTo().getId());
                context.setSystemObject1(so1);
                context.setSystemObject2(so2);
                context.setComparison(ctx.getComparison());

                final WorkflowTask task = taskGenerator.generateTask(context);

                ProcessInstance pi = WorkflowServiceHelper.getService(Activator.getBC()).createProcessInstanceByKey(cc, task.getProcessDefinitionKey(), task.getBusinessKey(),
                    task.getSummaryText(), task.getFormProperties(), task.getVariables(), task.getLabels(), task.getSecurityLabels());
                pis.add(pi);
            }
        }

        LOG.trace("[end] wfStartPotentialDuplicate: {}", msMsg);
        return pis;
    }

    /**
     * Complete potential duplicate.
     *
     * @param conf the configuration entry
     * @param exch the exchange
     * @param msMsg the ngms message
     * @param req the mm notification request
     * @param compt the comparisons
     * @param action the action
     * @param processInstanceIds the process instance ids
     * @throws Exception on error
     */
    public void completePotentialDuplicate(final ConfigurationCacheEntry conf, final Exchange exch, final NGMSMessage msMsg,
        final MMNotificationResponse req, final ComparisonType compt,
        final String action, final Set<String> processInstanceIds) throws Exception {

        LOG.trace("[begin] wfCompletePotentialDuplicate: {}", msMsg);

        final WorkflowSenderInstanceGroup wsig = (WorkflowSenderInstanceGroup) conf.getComponentInstanceSettings();

        final CallerContext caller = WorkflowHelper.getInstance().getCallerContext(msMsg);
        final CallerContext cc = msMsg.getAuthority().toCallerContext();

        if (GeneralString.trimString(wsig.getTaskScriptPotentialDup()) == null) {

            LOG.trace("[end] wfCompletePotentialDuplicate - NO TASK SCRIPT CONFIGURED: {}", msMsg);
            return;
        }

        if (msMsg.countCanonicalData() < 1) {

            LOG.debug("[end] wfCompletePotentialDuplicate - NO Data Mapped: {}", msMsg);
            return;
        }

        if (req.getRegistry() == RegistryType.PERSON) {

            final PersonType person = msMsg.getCanonicalData().get(0).getPerson();
            final PersonType priorPerson = msMsg.getCanonicalData().get(0).getPriorPerson();

            if ((person == null) || (person.countPersonIds() < 1)) {

                LOG.debug("[end] wfCompletePotentialDuplicate - NO vald person: {}", msMsg);
                return;
            }

            if ((priorPerson == null) || (priorPerson.countPersonIds() < 1)) {

                LOG.debug("[end] wfCompletePotentialDuplicate - NO vald prior person: {}", msMsg);
                return;
            }
        }
        else {
            final ProviderType provider = msMsg.getCanonicalData().get(0).getProvider();
            final ProviderType priorProvider = msMsg.getCanonicalData().get(0).getPriorProvider();

            if ((provider == null) || (provider.countLocalIds() < 1)) {

                LOG.debug("[end] wfCompletePotentialDuplicate - NO vald provider: {}", msMsg);
                return;
            }

            if ((priorProvider == null) || (priorProvider.countLocalIds() < 1)) {

                LOG.debug("[end] wfCompletePotentialDuplicate - NO vald prior provider: {}", msMsg);
                return;
            }
        }

        if (WorkflowConstants.T_UPDATETASK.equals(action)) {

            final MasterController mc = WorkflowHelper.getInstance().getMasterController(conf);

            final EnterpriseObject eo1 = mc.getEnterpriseObject(caller, compt.getCompareFrom().getId());
            final EnterpriseObject eo2 = mc.getEnterpriseObject(caller, compt.getCompareTo().getId());

            final List<MarkedUnique> mus = mc.lookupMarkedUniquesForEuids(caller, Long.parseLong(eo1.getEUID()), Long.parseLong(eo2.getEUID()));

            for (final SystemObject so1 : eo1.getSystemObjects()) {

                if (!(SystemObject.STATUS_ACTIVE.equals(so1.getStatus()))) {

                    continue;
                }

                final String systemCode1 = so1.getSystemCode();

                for (final SystemObject so2 : eo2.getSystemObjects()) {

                    if (!(SystemObject.STATUS_ACTIVE.equals(so2.getStatus()))) {

                        continue;
                    }

                    final String systemCode2 = so2.getSystemCode();

                    if (!(systemCode1.equals(systemCode2))) {

                        continue;
                    }

                    final Map<String, Object> props = new HashMap<>();

                    props.put(WorkflowConstants.T_POTENTIALDUPLICATEID, Long.parseLong(compt.getId()));
                    props.put(WorkflowConstants.T_SYS1, systemCode1);
                    props.put(WorkflowConstants.T_LID1, so1.getLID());
                    props.put(WorkflowConstants.T_SYS2, systemCode2);
                    props.put(WorkflowConstants.T_LID2, so2.getLID());

                    List<ProcessInstance> pis = WorkflowServiceHelper.getService(Activator.getBC()).getProcessInstances(cc, null,
                        WorkflowHelper.getInstance().getProcessDefinitionKey(wsig, WorkflowConstants.T_SAMESYSTEMPOTENTIALDUPLICATE), null, props);

                    // check the reverse too
                    props.put(WorkflowConstants.T_SYS1, systemCode2);
                    props.put(WorkflowConstants.T_LID1, so2.getLID());
                    props.put(WorkflowConstants.T_SYS2, systemCode1);
                    props.put(WorkflowConstants.T_LID2, so1.getLID());

                    pis.addAll(WorkflowServiceHelper.getService(Activator.getBC()).getProcessInstances(cc, null,
                        WorkflowHelper.getInstance().getProcessDefinitionKey(wsig, WorkflowConstants.T_SAMESYSTEMPOTENTIALDUPLICATE), null, props));

                    if (this.isLidsMarkedUnique(mus, systemCode1, so1.getLID(), systemCode2, so2.getLID())) {
                        for (final ProcessInstance pi : pis) {
                            WorkflowServiceHelper.getService(Activator.getBC()).removeProcessInstance(cc, pi.getId(), "LIDs marked unique");
                        }

                        continue;
                    }

                    if (pis == null) {

                        continue;
                    }

                    for (final ProcessInstance pi : pis) {

                        if (pi.isEnded()) {

                            continue;
                        }
                        
                        // acquire lock on the PI
                        LockInterface lock = ClusterInterface.ClusterServiceHelper.getService(Activator.getBC()).getLock(PROCESS_INSTANCE + pi.getId());
                        lock.acquireSemaphore(true);

                        try {
                            if (!(processInstanceIds.contains(pi.getId()))) {
                                final PotentialDuplicateTaskGenerator taskGenerator = (PotentialDuplicateTaskGenerator) WorkflowSenderFactory.getGroovyLoader(wsig).newInstance(wsig.getTaskScriptPotentialDup());
                                final PotentialDuplicateContext context = new PotentialDuplicateContext();

                                context.setExchange(exch);
                                context.setMessage(msMsg);
                                context.setNotification(req);
                                context.setEUID1(eo1.getEUID());
                                context.setEUID2(eo2.getEUID());
                                context.setSystemObject1(so1);
                                context.setSystemObject2(so2);
                                context.setComparison(compt);

                                final WorkflowTask task = taskGenerator.generateTask(context);

                                WorkflowServiceHelper.getService(Activator.getBC()).setProcessInstanceSummary(cc, pi.getId(), task.getSummaryText());

                                final Map<String, Object> variables = new HashMap<>();
                                variables.put(WEIGHT, compt.getOverallScore());
                                variables.put(IDS, generateIds(context));
                                WorkflowServiceHelper.getService(Activator.getBC()).setProcessInstanceVariables(cc, pi.getId(), variables);
                            }
                        } catch (Exception ex) {
                            LOG.debug("Exception occurred while locked", ex);
                            throw ex;
                        } finally {
                            // release lock on PI
                            lock.releaseSemaphore();
                        }
                    }
                }
            }
        }

        final Map<String, Object> processProps = new HashMap<String, Object>();

        processProps.put(WorkflowConstants.T_POTENTIALDUPLICATEID, Long.parseLong(compt.getId()));

        final List<ProcessInstance> pis = WorkflowServiceHelper.getService(Activator.getBC()).getProcessInstances(cc, null,
            WorkflowHelper.getInstance().getProcessDefinitionKey(wsig, WorkflowConstants.T_SAMESYSTEMPOTENTIALDUPLICATE), null, processProps);

        if (pis != null) {

            final TasksRequest request = new TasksRequest();

            for (final ProcessInstance pi : pis) {

                if (pi.isEnded()) {

                    continue;
                }
                
                // acquire lock on the PI
                LockInterface lock = ClusterInterface.ClusterServiceHelper.getService(Activator.getBC()).getLock(PROCESS_INSTANCE + pi.getId());
                lock.acquireSemaphore(true);

                try {
                    if (WorkflowConstants.T_DELETEPI.equals(action)) {

                        // see if the PI has any tasks
                        request.setProcessInstanceId(pi.getId());
                        final TasksResponse tasks = WorkflowServiceHelper.getService(Activator.getBC()).getTasks(cc, request);

                        // if there are tasks, delete the PI, otherwise consider it in-progress and let it complete
                        if (tasks.getTotalTasks() > 0) {

                            try {
                                WorkflowServiceHelper.getService(Activator.getBC()).removeProcessInstance(cc, pi.getId(), "Potential duplicate removed due to external merge");
                            }
                            catch (final Exception ex) {

                                LOG.warn("Exception removing PI, ignoring", ex);
                            }
                        }
                        else {
                            LOG.debug("Process instance {} has no tasks, not deleting", pi.getId());
                        }

                        continue;
                    }

                    final List<Task> tasks = WorkflowServiceHelper.getService(Activator.getBC()).getProcessInstanceTasks(cc, pi.getId(), false, true);

                    if (tasks == null) {

                        LOG.warn("wfCompletePotentialDuplicate: No tasks currently found for [" +
                            WorkflowConstants.T_SAMESYSTEMPOTENTIALDUPLICATE + EUIDS_LOG,
                            compt.getCompareFrom().getId(), compt.getCompareTo().getId());

                        //
                        // later: if for some reason the task did not exist, it needs to be created
                        // For example, a perm unique dup getting unresolved...
                        //
                        continue;
                    }

                    for (final Task task : tasks) {

                        final FormInfo form = task.getForm();

                        boolean completeTask = false;

                        if (form != null) {

                            for (final FormProp prop : form.getFormProperties()) {

                                if (WorkflowConstants.T_ACTION.equals(prop.getId())) {

                                    if (prop.getValues() != null) {

                                        if (prop.getValues().containsKey(action)) {

                                            completeTask = true;
                                            break;
                                        }
                                        //From DQM use case, task was not being completed previously due to the form values for action in the 
                                        //Review Potential Duplicate and Review Potential Match user tasks not containing the following values: 
                                        //'externalUnique' and 'externalNotUnique' which are used for Mark Review and Unmark Review operations, respectively.
                                        else if( (action.equals(WorkflowConstants.T_EXTERNALUNIQUE) && prop.getValues().containsKey(WorkflowConstants.T_UNIQUE)) ||
                                                 (action.equals(WorkflowConstants.T_EXTERNALNOTUNIQUE) && prop.getValues().containsKey(WorkflowConstants.T_NOTUNIQUE)) ) {

                                            Date endTime = task.getEndTime();
                                            if(endTime == null) {

                                                completeTask = true;
                                                break;
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        if (completeTask) {

                            this.completeTask(cc, action, msMsg, task);
                            processInstanceIds.add(task.getProcessInstanceId());
                        }
                    }                
                } catch (Exception ex) {
                    LOG.debug("Exception occurred while locked", ex);
                    throw ex;
                } finally {
                    // release lock on PI
                    lock.releaseSemaphore();
                }
            }
        }

        LOG.trace("[end] wfCompletePotentialDuplicate: {}", msMsg);
    }

    /**
     * Start potential match.
     *
     * @param conf the configuration entry
     * @param exch the exchange
     * @param msMsg the ngms message
     * @param req the mm notification request
     * @param compt the comparisons
     * @throws Exception on error
     */
    public void startPotentialMatch(final ConfigurationCacheEntry conf, final Exchange exch, final NGMSMessage msMsg,
        final MMNotificationResponse req, final ComparisonType compt) throws Exception {

        LOG.trace("[begin] wfStartPotentialMatch: {}", msMsg);

        final WorkflowSenderInstanceGroup wsig = (WorkflowSenderInstanceGroup) conf.getComponentInstanceSettings();

        final String taskScript = GeneralString.trimString(wsig.getTaskScriptPotentialMatch());

        if (taskScript == null) {

            LOG.trace("[end] wfStartPotentialMatch - NO TASK SCRIPT CONFIGURED: {}", msMsg);
            return;
        }

        final WorkflowUpdateContext ctx = new WorkflowUpdateContext();

        ctx.setAppName(wsig.getAppName());
        ctx.setAuditUser(msMsg.getAuthority().getAuditUser());
        ctx.setComparison(compt);
        ctx.setExchange(exch);
        ctx.setMessage(msMsg);
        ctx.setNotification(req);
        ctx.setTenant(msMsg.getAuthority().getTenant());
        ctx.setTransId(msMsg.getMessageControlId());

        final CallerContext caller = new CallerContext();
        caller.setTenant(ctx.getTenant());

        final MasterController mc = WorkflowHelper.getInstance().getMasterController(conf);

        final SBR sbr1 = mc.getSBR(caller, compt.getCompareFrom().getId());
        final SBR sbr2 = mc.getSBR(caller, compt.getCompareTo().getId());

        if ((sbr1 == null) || (sbr2 == null)) {

            LOG.warn("[startPotentialMatch] potential match requires two SBR references 1 [{}] 2 [{}]", sbr1, sbr2);
            return;
        }

        final SystemObjectPK[] lids1 = mc.lookupSystemObjectPKs(caller, compt.getCompareFrom().getId());
        final SystemObjectPK[] lids2 = mc.lookupSystemObjectPKs(caller, compt.getCompareTo().getId());

        final List<MarkedUnique> mus = mc.lookupMarkedUniquesForEuids(caller, Long.parseLong(sbr1.getLID()), Long.parseLong(sbr2.getLID()));

        this.startPotentialMatch(conf, msMsg, ctx, sbr1, sbr2, lids1, lids2, mus, false);

        LOG.trace("[end] wfStartPotentialMatch: {}", msMsg);
    }

    /**
     * Start potential match.
     *
     * @param conf the configuration entry
     * @param msMsg the ngms message
     * @param ctx the workflow context
     * @param sbr1 the SBR 1
     * @param sbr2 the SBR 2
     * @param lids1 the LIDs 1
     * @param lids2 the LIDs 2
     * @return the process instance
     * @throws Exception on error
     */
    public ProcessInstance startPotentialMatch(final ConfigurationCacheEntry conf, final NGMSMessage msMsg, final WorkflowUpdateContext ctx, final SBR sbr1, final SBR sbr2,
        final SystemObjectPK[] lids1, final SystemObjectPK[] lids2, final List<MarkedUnique> mus, final boolean skipChecks) throws Exception {

        LOG.trace("[begin] wfStartPotentialMatch: {}", msMsg);

        final WorkflowSenderInstanceGroup wsig = (WorkflowSenderInstanceGroup) conf.getComponentInstanceSettings();

        final CallerContext cc = msMsg.getAuthority().toCallerContext();

        final String taskScript = GeneralString.trimString(wsig.getTaskScriptPotentialMatch());

        if (taskScript == null) {
            LOG.debug("Task script is null- skipping Potential Match task creation.");
            return null;
        }

        // load-tasks can skip checks for initial loads to improve performance

        if (!skipChecks) {
            // check to see if already created, needed since this creation is called on updates now

            final Map<String, Object> props = new HashMap<>();

            props.put(WorkflowConstants.T_POTENTIALDUPLICATEID, Long.parseLong(ctx.getComparison().getId()));
            props.put(WorkflowConstants.T_EUID1, Long.parseLong(sbr1.getLID()));
            props.put(WorkflowConstants.T_EUID2, Long.parseLong(sbr2.getLID()));

            List<ProcessInstance> pis = WorkflowServiceHelper.getService(Activator.getBC()).getProcessInstances(cc, null,
                WorkflowHelper.getInstance().getProcessDefinitionKey(wsig, WorkflowConstants.T_POTENTIALMATCHPROCESS), null, props);

            if (!pis.isEmpty()) {
                // found a PI, don't recreate
                LOG.debug("Found a Same-System Task for EUIDs {} and {}. Skipping cross-system task creation.", sbr1.getLID(), sbr2.getLID());
                return null;
            }

            // check the reverse too
            props.put(WorkflowConstants.T_EUID1, Long.parseLong(sbr2.getLID()));
            props.put(WorkflowConstants.T_EUID2, Long.parseLong(sbr1.getLID()));

            pis = WorkflowServiceHelper.getService(Activator.getBC()).getProcessInstances(cc, null,
                WorkflowHelper.getInstance().getProcessDefinitionKey(wsig, WorkflowConstants.T_POTENTIALMATCHPROCESS), null, props);

            if (!pis.isEmpty()) {
                // found a PI, don't recreate
                LOG.debug("Found a Same-System Task for EUIDs {} and {}. Skipping cross-system task creation.", sbr2.getLID(), sbr1.getLID());
                return null;
            }

            // only create the pot-match if there is at least one non-marked unique LID pair between the records

            boolean create = false;

            outer:
            for (final SystemObjectPK lid1 : lids1) {
                for (final SystemObjectPK lid2 : lids2) {
                    if (!this.isLidsMarkedUnique(mus, lid1.getSystemCode(), lid1.getlID(), lid2.getSystemCode(), lid2.getlID())) {
                        LOG.debug("No marked unique found for {}/{} and {}/{} so can create pot-match", lid1.getSystemCode(), lid1.getlID(), lid2.getSystemCode(), lid2.getlID());
                        create = true;
                        break outer;
                    }
                    else {
                        LOG.debug("Marked unique entry found for {}/{} and {}/{}", lid1.getSystemCode(), lid1.getlID(), lid2.getSystemCode(), lid2.getlID());
                    }
                }
            }

            if (!create) {
                LOG.debug("LID marked unique pair precluded creating pot-match for EUIDs {} and {}", sbr1.getLID(), sbr2.getLID());
                return null;
            }
        }

        final PotentialMatchTaskGenerator taskGenerator = (PotentialMatchTaskGenerator) WorkflowSenderFactory.getGroovyLoader(wsig).newInstance(taskScript);

        final PotentialMatchContext context = new PotentialMatchContext();

        context.setExchange(ctx.getExchange());
        context.setMessage(ctx.getMessage());
        context.setNotification(ctx.getNotification());
        context.setSBR1(sbr1);
        context.setSBR2(sbr2);
        context.setSystemObjectKeys1(lids1);
        context.setSystemObjectKeys2(lids2);
        context.setEUID1(ctx.getComparison().getCompareFrom().getId());
        context.setEUID2(ctx.getComparison().getCompareTo().getId());
        context.setComparison(ctx.getComparison());

        final WorkflowTask task = taskGenerator.generateTask(context);

        final ProcessInstance pi = WorkflowServiceHelper.getService(Activator.getBC()).createProcessInstanceByKey(cc, task.getProcessDefinitionKey(), task.getBusinessKey(),
            task.getSummaryText(), task.getFormProperties(), task.getVariables(), task.getLabels(), task.getSecurityLabels());

        LOG.trace("[end] wfStartPotentialMatch: {}", msMsg);
        return pi;
    }

    /**
     * Complete a potential match.
     *
     * @param conf the configuration entry
     * @param exch the exchange
     * @param msMsg the ngms message
     * @param req the mm notification request
     * @param compt the comparisons
     * @param action the action
     * @param compt comparisons
     * @param processInstanceIds the process instance ids
     * @throws Exception on error
     */
    public void completePotentialMatch(final ConfigurationCacheEntry conf, final Exchange exch, final NGMSMessage msMsg,
        final MMNotificationResponse req, final ComparisonType compt,
        final String action, final Set<String> processInstanceIds) throws Exception {

        LOG.trace("[begin] wfCompletePotentialMatch: {}", msMsg);

        final WorkflowSenderInstanceGroup wsig = (WorkflowSenderInstanceGroup) conf.getComponentInstanceSettings();
        final String script = GeneralString.trimString(wsig.getTaskScriptPotentialMatch());

        if (script == null) {

            LOG.trace("[end] wfCompletePotentialMatch - NO TASK SCRIPT CONFIGURED: {}", msMsg);

            return;
        }

        final CallerContext cc = msMsg.getAuthority().toCallerContext();

        final Map<String, Object> processProps = new HashMap<String, Object>();

        processProps.put(WorkflowConstants.T_POTENTIALDUPLICATEID, Long.parseLong(compt.getId()));

        final List<ProcessInstance> pis = WorkflowServiceHelper.getService(Activator.getBC()).getProcessInstances(cc, null,
            WorkflowHelper.getInstance().getProcessDefinitionKey(wsig, WorkflowConstants.T_POTENTIALMATCHPROCESS), null, processProps);

        final MasterController mc = WorkflowHelper.getInstance().getMasterController(conf);

        final CallerContext caller = WorkflowHelper.getInstance().getCallerContext(msMsg);

        if ((pis != null) && !pis.isEmpty()) {

            final String euid1 = compt.getCompareFrom().getId();
            final String euid2 = compt.getCompareTo().getId();

            boolean delete = false;

            if ((euid1 != null) && (euid2 != null) && !euid1.equals(euid2)) {

                final List<MarkedUnique> mus = mc.lookupMarkedUniquesForEuids(caller, Long.parseLong(euid1), Long.parseLong(euid2));

                final SystemObjectPK[] lids1 = mc.lookupSystemObjectPKs(caller, euid1);
                final SystemObjectPK[] lids2 = mc.lookupSystemObjectPKs(caller, euid2);

                if ((lids1 != null) && (lids2 != null)) {
                    // only keep the pot-match if there is at least one non-marked unique LID pair between the records

                    delete = true;

                    for (final SystemObjectPK lid1 : lids1) {
                        for (final SystemObjectPK lid2 : lids2) {
                            if (!this.isLidsMarkedUnique(mus, lid1.getSystemCode(), lid1.getlID(), lid2.getSystemCode(), lid2.getlID())) {
                                LOG.debug("No marked unique found for {}/{} and {}/{} so can create pot-match", lid1.getSystemCode(), lid1.getlID(), lid2.getSystemCode(), lid2.getlID());
                                delete = false;
                                break;
                            }
                        }

                        if (!delete) {
                            break;
                        }
                    }

                    if (delete) {
                        LOG.debug("Marked unique(s) require pot-match removal");
                    }
                }
            }

            final TasksRequest request = new TasksRequest();

            for (final ProcessInstance pi : pis) {

                if (pi.isEnded()) {

                    continue;
                }
                
                // acquire lock on the PI
                LockInterface lock = ClusterInterface.ClusterServiceHelper.getService(Activator.getBC()).getLock(PROCESS_INSTANCE + pi.getId());
                lock.acquireSemaphore(true);

                try {
                    if (WorkflowConstants.T_DELETEPI.equals(action) || delete) {

                        // see if the PI has any tasks
                        request.setProcessInstanceId(pi.getId());
                        final TasksResponse tasks = WorkflowServiceHelper.getService(Activator.getBC()).getTasks(cc, request);

                        // if there are tasks, delete the PI, otherwise consider it in-progress and let it complete
                        if (tasks.getTotalTasks() > 0) {

                            try {
                                WorkflowServiceHelper.getService(Activator.getBC()).removeProcessInstance(cc, pi.getId(), "Potential match removed due to external merge");
                            }
                            catch (final Exception ex) {

                                LOG.warn("Exception removing PI, ignoring", ex);
                            }
                        }
                        else {
                            LOG.debug("Process instance {} has no tasks, not deleting", pi.getId());
                        }

                        continue;
                    }

                    if ((WorkflowConstants.T_UPDATETASK.equals(action)) && !(processInstanceIds.contains(pi.getId()))) {

                        final PotentialMatchTaskGenerator taskGenerator = (PotentialMatchTaskGenerator) WorkflowSenderFactory.getGroovyLoader(wsig).newInstance(script);
                        final PotentialMatchContext context = new PotentialMatchContext();
                        context.setExchange(exch);
                        context.setMessage(msMsg);
                        context.setNotification(req);

                        final SBR sbr1 = mc.getSBR(caller, euid1);

                        if (sbr1 == null) {

                            throw new InvalidParameterException("Unable to find Compare FROM id: {}", euid1);
                        }

                        final SBR sbr2 = mc.getSBR(caller, euid2);

                        if (sbr2 == null) {

                            throw new InvalidParameterException("Unable to find Compare TO id: {}", euid2);
                        }

                        final SystemObjectPK[] lids1 = mc.lookupSystemObjectPKs(caller, euid1);
                        final SystemObjectPK[] lids2 = mc.lookupSystemObjectPKs(caller, euid2);

                        context.setSBR1(sbr1);
                        context.setEUID1(compt.getCompareFrom().getId());
                        context.setSystemObjectKeys1(lids1);
                        context.setSBR2(sbr2);
                        context.setEUID2(compt.getCompareTo().getId());
                        context.setSystemObjectKeys2(lids2);
                        context.setComparison(compt);

                        final WorkflowTask task = taskGenerator.generateTask(context);

                        WorkflowServiceHelper.getService(Activator.getBC()).setProcessInstanceSummary(cc, pi.getId(), task.getSummaryText());
                        final Map<String, Object> variables = new HashMap<>();

                        final Map<String, Object> taskVars = task.getVariables();

                        if (taskVars != null) {

                            variables.putAll(task.getVariables());
                        }

                        variables.put(WEIGHT, compt.getOverallScore());
                        variables.put(IDS, generateIds(context));
                        WorkflowServiceHelper.getService(Activator.getBC()).setProcessInstanceVariables(cc, pi.getId(), variables);
                    }

                    final List<Task> tasks = WorkflowServiceHelper.getService(Activator.getBC()).getProcessInstanceTasks(cc, pi.getId(), false, true);

                    if (tasks == null) {

                        LOG.warn("wfCompletePotentialMatch: No tasks currently found for [" + WorkflowConstants.T_POTENTIALMATCHPROCESS + EUIDS_LOG,
                            compt.getCompareFrom().getId(), compt.getCompareTo().getId());

                        //
                        // later: if for some reason the task did not exist, it needs to be created
                        // For example, a perm unique dup getting unresolved...
                        //
                        continue;
                    }

                    for (final Task task : tasks) {

                        final FormInfo form = task.getForm();

                        boolean completeTask = false;

                        if (form != null) {

                            for (final FormProp prop : form.getFormProperties()) {

                                if (WorkflowConstants.T_ACTION.equals(prop.getId())) {

                                    if (prop.getValues() != null) {

                                        if (prop.getValues().containsKey(action)) {

                                            completeTask = true;
                                            break;
                                        }
                                        //From DQM use case, task was not being completed previously due to the form values for action in the 
                                        //Review Potential Duplicate and Review Potential Match user tasks not containing the following values: 
                                        //'externalUnique' and 'externalNotUnique' which are used for Mark Review and Unmark Review operations, respectively.
                                        else if( (action.equals(WorkflowConstants.T_EXTERNALUNIQUE) && prop.getValues().containsKey(WorkflowConstants.T_UNIQUE)) ||
                                            (action.equals(WorkflowConstants.T_EXTERNALNOTUNIQUE) && prop.getValues().containsKey(WorkflowConstants.T_NOTUNIQUE)) ) {

                                            Date endTime = task.getEndTime();
                                            if(endTime == null) {

                                                completeTask = true;
                                                break;
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // NOTE: completeTask method will not be invoked for existing BPMNs for v10 WF
                        if (completeTask) {

                            this.completeTask(cc, action, msMsg, task);
                        }
                    }
                } catch (Exception ex) {
                    LOG.debug("Exception occurred while locked", ex);
                    throw ex;
                } finally {                
                    // release lock on PI
                    lock.releaseSemaphore();
                }
            }
        }

        LOG.trace("[end] wfCompletePotentialMatch: {}", msMsg);
    }

    /**
     * start an assumed match process.
     *
     * @param conf the configuration entry
     * @param exch the exchange
     * @param msMsg the ngms message
     * @param req the mm notification request
     * @param compt the comparisons
     * @param isMatch used to determine which case is being processed (add/match or add/add/upd/upd/euidMerge); true is for former case
     * @throws Exception on error
     */
    public void startAssumedMatch(final ConfigurationCacheEntry conf, final Exchange exch, final NGMSMessage msMsg,
        final MMNotificationResponse req, final ComparisonType compt, final boolean isMatch) throws Exception {

        LOG.trace("[begin] wfStartAssumedMatch: {}", msMsg);

        final WorkflowSenderInstanceGroup wsig = (WorkflowSenderInstanceGroup) conf.getComponentInstanceSettings();

        final String taskScript = GeneralString.trimString(wsig.getTaskScriptAssumedMatch());

        if (taskScript == null) {

            LOG.trace("[end] wfStartAssumedMatch - NO TASK SCRIPT CONFIGURED: {}", msMsg);
            return;
        }

        final WorkflowUpdateContext ctx = new WorkflowUpdateContext();

        ctx.setAppName(wsig.getAppName());
        ctx.setAuditUser(msMsg.getAuthority().getAuditUser());
        ctx.setComparison(compt);
        ctx.setExchange(exch);
        ctx.setMessage(msMsg);
        ctx.setNotification(req);
        ctx.setTenant(msMsg.getAuthority().getTenant());
        ctx.setTransId(msMsg.getMessageControlId());

        String systemCode = null;
        String lid = null;

        if (isMatch) {
            systemCode = compt.getCompareFrom().getAssigningAuthority().getNamespaceId();
            lid = compt.getCompareFrom().getId();
        }

        this.startAssumedMatch(conf, msMsg, ctx, compt, systemCode, lid, isMatch);

        LOG.trace("[end] wfStartAssumedMatch: {}", msMsg);
    }

    /**
     * Start an assumed match process.
     *
     * @param conf the configuration entry
     * @param msMsg the ngms message
     * @param ctx the workflow context
     * @param compt the comparison type
     * @param systemCode the system code
     * @param lid the local identifier
     * @param isMatch used to determine which case is being processed (add/match or add/add/upd/upd/euidMerge); true is for former case
     * @return the process instance
     * @throws Exception on error
     */
    public ProcessInstance startAssumedMatch(final ConfigurationCacheEntry conf, final NGMSMessage msMsg, final WorkflowUpdateContext ctx, final ComparisonType compt,
        final String systemCode, final String lid, final boolean isMatch) throws Exception {

        LOG.trace("[begin] wfStartAssumedMatch: {}", msMsg);

        final WorkflowSenderInstanceGroup wsig = (WorkflowSenderInstanceGroup) conf.getComponentInstanceSettings();

        final CallerContext cc = msMsg.getAuthority().toCallerContext();

        final String taskScript = GeneralString.trimString(wsig.getTaskScriptAssumedMatch());

        if (taskScript == null) {

            return null;
        }

        final AssumedMatchTaskGenerator taskGenerator = (AssumedMatchTaskGenerator) WorkflowSenderFactory.getGroovyLoader(wsig).newInstance(taskScript);

        final AssumedMatchContext context = new AssumedMatchContext();
        final String transId = msMsg.getMessageControlId();

        final MasterController mc = WorkflowHelper.getInstance().getMasterController(conf);

        final TransactionSummary transSummary = mc.lookupTransaction(WorkflowHelper.getInstance().getCallerContext(msMsg), transId);

        if (isMatch) {
            context.setAfterEo(transSummary.getEnterpriseObjectHistory().getAfterEO());
            context.setNewSo(transSummary.getEnterpriseObjectHistory().getAfterEO().getSystemObject(systemCode, lid));
        }
        else {
            context.setAfterEo(transSummary.getEnterpriseObjectHistory().getAfterEO());
            context.setBeforeEo2(transSummary.getEnterpriseObjectHistory().getBeforeEO2());
        }

        context.setExchange(ctx.getExchange());
        context.setMessage(ctx.getMessage());
        context.setNotification(ctx.getNotification());
        context.setComparison(compt);
        context.setMatch(isMatch);

        final WorkflowTask task = taskGenerator.generateTask(context);

        final ProcessInstance pi = WorkflowServiceHelper.getService(Activator.getBC()).createProcessInstanceByKey(cc, task.getProcessDefinitionKey(), task.getBusinessKey(),
            task.getSummaryText(), task.getFormProperties(), task.getVariables(), task.getLabels(), task.getSecurityLabels());

        LOG.trace("[end] wfStartAssumedMatch: {}", msMsg);
        return pi;
    }

    /**
     * Complete an assumed match.
     *
     * @param conf the configuration
     * @param exch the exchange
     * @param msMsg the message
     * @param req the request
     * @param action the action
     * @throws Exception if an error occurs
     */
    public void completeAssumedMatch(final ConfigurationCacheEntry conf, final Exchange exch, final NGMSMessage msMsg, final MMNotificationResponse req, final String action) throws Exception {

        LOG.trace("[begin] wfCompleteAssumedMatch: {}", msMsg);

        final WorkflowSenderInstanceGroup wsig = (WorkflowSenderInstanceGroup) conf.getComponentInstanceSettings();

        if (GeneralString.trimString(wsig.getTaskScriptAssumedMatch()) == null) {

            LOG.trace("[end] wfCompleteAssumedMatch - NO TASK SCRIPT CONFIGURED: {}", msMsg);
            return;
        }

        final CallerContext cc = msMsg.getAuthority().toCallerContext();

        final Map<String, Object> processProps = new HashMap<>();

        if (req.getRegistry() == RegistryType.PERSON) {
            final String euid = msMsg.getCanonicalData().get(0).getPriorPerson().getEuid().getId();
            processProps.put(WorkflowConstants.T_EUID, Long.parseLong(euid));
        }
        else {
            final String euid = msMsg.getCanonicalData().get(0).getPriorProvider().getEuid().getId();
            processProps.put(WorkflowConstants.T_EUID, Long.parseLong(euid));
        }

        final List<ProcessInstance> pis = WorkflowServiceHelper.getService(Activator.getBC()).getProcessInstances(cc, null,
            WorkflowHelper.getInstance().getProcessDefinitionKey(wsig, WorkflowConstants.T_ASSUMEDMATCHREVIEWPROCESS), null, processProps);

        if (pis != null) {

            final TasksRequest request = new TasksRequest();

            for (final ProcessInstance pi : pis) {

                if (pi.isEnded()) {

                    continue;
                }

                if (WorkflowConstants.T_DELETEPI.equals(action)) {

                    // see if the PI has any tasks
                    request.setProcessInstanceId(pi.getId());
                    final TasksResponse tasks = WorkflowServiceHelper.getService(Activator.getBC()).getTasks(cc, request);

                    // if there are tasks, delete the PI, otherwise consider it in-progress and let it complete
                    if (tasks.getTotalTasks() > 0) {

                        try {
                            WorkflowServiceHelper.getService(Activator.getBC()).removeProcessInstance(cc, pi.getId(), "Assumed match removed due to external split");
                        }
                        catch (final Exception ex) {

                            LOG.warn("Exception removing PI, ignoring", ex);
                        }
                    }
                    else {
                        LOG.debug("Process instance {} has no tasks, not deleting", pi.getId());
                    }

                    continue;
                }
            }
        }

        LOG.trace("[end] wfCompleteAssumedMatch: {}", msMsg);
    }

    private boolean isLidsMarkedUnique(final List<MarkedUnique> mus, final String systemCode1, final String lid1, final String systemCode2, final String lid2) {

        for (final MarkedUnique mu : mus) {
            if ((mu.getStatus() == MarkedUnique.Status.U) &&
                ((mu.getSystem1().equals(systemCode1) && mu.getLid1().equals(lid1) && mu.getSystem2().equals(systemCode2) && mu.getLid2().equals(lid2)) || (mu.getSystem1().equals(systemCode2) && mu.getLid1().equals(lid2) && mu.getSystem2().equals(systemCode1) && mu.getLid2().equals(lid1)))) {
                return true;
            }
        }

        return false;
    }

    //Used to update Potential Duplicate ID list for task variable
    private String generateIds(PotentialDuplicateContext context) {

        StringBuilder sb = new StringBuilder();

        sb.append(",")
            .append("EUID/").append(context.getEUID1()).append(",")
            .append("EUID/").append(context.getEUID2()).append(",")
            .append(context.getSystemObject1().getSystemCode())
            .append("/")
            .append(context.getSystemObject1().getLID())
            .append(",")
            .append(context.getSystemObject2().getSystemCode())
            .append("/")
            .append(context.getSystemObject2().getLID())
            .append(",");

        return sb.toString();
    }

    //Used to update Potential Match ID list for task variable
    private String generateIds(PotentialMatchContext context) {

        StringBuilder sb = new StringBuilder();

        sb.append(",")
            .append("EUID/").append(context.getEUID1()).append(",")
            .append("EUID/").append(context.getEUID2()).append(",");

        for (SystemObjectPK pk : context.getSystemObjectKeys1()) {
            sb.append(pk.getSystemCode())
                .append("/")
                .append(pk.getlID())
                .append(",");
        }

        for (SystemObjectPK pk : context.getSystemObjectKeys2()) {
            sb.append(pk.getSystemCode())
                .append("/")
                .append(pk.getlID())
                .append(",");
        }

        return sb.toString();
    }

    private static Map<String, String> convertProperties(final Map<String, Object> props) {

        final Map<String, String> ret = new HashMap<String, String>();

        for (final Entry<String, Object> entry : props.entrySet()) {

            if (entry.getValue() instanceof Long) {

                ret.put(entry.getKey(), ((Long) entry.getValue()).toString());
            }
            else if (entry.getValue() instanceof Double) {

                ret.put(entry.getKey(), ((Double) entry.getValue()).toString());
            }
            else if (entry.getValue() instanceof Date) {

                ret.put(entry.getKey(), DateUtils.formatDateTime((Date) entry.getValue(), DateUtils.DF_XMLDATETIMEFORMAT));
            }
            else {
                ret.put(entry.getKey(), entry.getValue().toString());
            }
        }

        return ret;
    }
    
    private void completeTask(final CallerContext cc, final String action, final NGMSMessage msMsg, final Task task) throws WorkflowBadRequestException, WorkflowForbiddenException, ResourceUnavailableException {
        
        LOG.trace("[begin] completeTask: taskId {} for action {}: msMsg {}", task.getId(), action, msMsg);

        final Map<String, Object> props = new HashMap<>();
        
        final Map<String, String> properties = new HashMap<>();
        
        //From DQM use case, task was not being completed previously due to the form values for action in the 
        //Review Potential Duplicate and Review Potential Match user tasks not containing the following values: 
        //'externalUnique' and 'externalNotUnique' which are used for Mark Review and Unmark Review operations, respectively.
        if(action.equals(WorkflowConstants.T_EXTERNALUNIQUE)) {
            
            properties.put(WorkflowConstants.T_ACTION, WorkflowConstants.T_UNIQUE);
        }
        else if(action.equals(WorkflowConstants.T_EXTERNALNOTUNIQUE)) {
            
            properties.put(WorkflowConstants.T_ACTION, WorkflowConstants.T_NOTUNIQUE);
        }
        else {
            
            properties.put(WorkflowConstants.T_ACTION, action);
        }
        
        props.put(PROPERTIES, properties);

        String auditUser = msMsg.getAuthority().getAuditUser();

        try {
            
            if(task.getAssignee() == null) {
                
                LOG.trace("completeTask: assigning task {} to user {}", task.getId(), auditUser);
                WorkflowServiceHelper.getService(Activator.getBC()).claimTask(cc, task.getId(), auditUser);
            }

            ValueListUtils.toTraceLog(LOG, P_PROPS, props);

            LOG.trace("completeTask: completing task {} for action {}", task.getId(), action);
            WorkflowServiceHelper.getService(Activator.getBC()).completeTask(cc, task.getId(), props, auditUser);
        }
        catch(WorkflowBadRequestException | WorkflowNotFoundException | WorkflowForbiddenException e) {
            
            //no op
            //in case of multiple notifications,
            //these exceptions may be thrown if the task is already completed
            //and deleted from ACT_RU_TASK table
            LOG.trace("completeTask: exception occurred", e);
        }

        LOG.trace("[end] completeTask: taskId {} for action {}", task.getId(), action);
    }
}
