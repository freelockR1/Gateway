/*
    Copyright (c) 2023, NextGate Solutions All Rights Reserved.

    This program, and all the NextGate Solutions authored routines referenced herein, 
    are the proprietary properties and trade secrets of NextGate Solutions.

    Except as provided for by license agreement, this program shall not be duplicated, 
    used, reversed engineered, decompiled, disclosed, shared, transferred, placed in a 
    publicly available location (such as but not limited to ftp sites, bit torrents, 
    shared drives, peer to peer networks, and such) without  written consent signed by 
    an officer of NextGate Solutions.

    DISCLAIMER:

    This software is provided as is without warranty of any kind. The entire risk as to 
    the results and performance of this software is assumed by the licensee and/or its 
    affiliates and/or assignees. NextGate Solutions disclaims all warranties, either 
    expressed or implied, including but not limited to the implied warranties of 
    merchantability, fitness for a particular purpose, title and non-infringement, with 
    respect to this software.
 */

import com.nextgate.interfaces.am.SecurityScript;
import com.nextgate.interfaces.workflow.api.objects.Task;
import java.util.Arrays;
import java.util.List;
import org.slf4j.Logger
import org.slf4j.LoggerFactory

/**
 * Security script to filter out any tasks that is not specified
 */
public class CrossSystemSYSBOnly implements SecurityScript {
    private static final transient Logger LOG = LoggerFactory.getLogger(CrossSystemSYSBOnly.class);

    private static final List<String> SYSTEMCODES = Arrays.asList("SYS_B");
    private static final List<String> LABELS = Arrays.asList("cross-system");

    @Override
    public List<String> getSecurityLabels() {
        return LABELS;
    }

    @Override
    public boolean isAccessible(Map<String, Object> context, Object resource, String action) {
        Task task = (Task) resource;

        // The ids variable has a comma separated list of identifiers, each being AA/LID
        // so tokenize and check for specified system code

        String[] ids = ((String) task.getVariables().get("ids")).split(",");

        for (String id : ids) {
            for (String sys : SYSTEMCODES) {
                if (id.contains(sys)) {
                    return true;
                }
            }
        }

        return false;
    }

    @Override
    public String getName() {
        return this.getClass().getName();
    }
}
