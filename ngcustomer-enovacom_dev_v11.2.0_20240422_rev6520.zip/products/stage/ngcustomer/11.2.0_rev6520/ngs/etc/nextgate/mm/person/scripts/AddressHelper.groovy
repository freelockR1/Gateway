import com.nextgate.mm.index.objects.person.AddressHistoryObject;
import com.nextgate.mm.index.objects.person.AddressObject;
import com.nextgate.mm.index.objects.person.PersonObject;
import com.sun.mdm.index.objects.SystemObjectException;
import com.sun.mdm.index.objects.exception.ObjectException;
import com.sun.mdm.index.objects.EnterpriseObject;
import com.sun.mdm.index.objects.SystemObject;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;

/**
 * Helper methods for Address handling
 */
public class AddressHelper {

    /** Creates a new instance of AddressHelper */
    public AddressHelper() {
    }

    private static String addressToString(AddressObject a) throws ObjectException {
        StringBuffer sb = new StringBuffer();
        sb.append(a.getAddressLine1()).append(a.getAddressLine2()).append(a.getAddressLine3()).
                append(a.getAddressLine4()).append(a.getCity()).append(a.getCounty()).append(a.getCountryCode()).
                append(a.getPostalCode()).append(a.getPostalCodeExt());
        return sb.toString().toUpperCase().replaceAll("\\W", "");
    }

    private static String addressToString(AddressHistoryObject a) throws ObjectException {
        StringBuffer sb = new StringBuffer();
        sb.append(a.getAddressLine1()).append(a.getAddressLine2()).append(a.getAddressLine3()).
                append(a.getAddressLine4()).append(a.getCity()).append(a.getCounty()).append(a.getCountryCode()).
                append(a.getPostalCode()).append(a.getPostalCodeExt());
        return sb.toString().toUpperCase().replaceAll("\\W", "");
    }

    /**
     * Add Address to SO's whose address has changed
     * @param beforeImage before image
     * @param afterImage after image
     * @throws SystemObjectException exception
     * @throws ObjectException exception
     */
    public static void addChangedAddressSO(EnterpriseObject beforeImage,
    EnterpriseObject afterImage) throws SystemObjectException, ObjectException {
        Collection<SystemObject> afterSysObjs = afterImage.getSystemObjects();
        if (afterSysObjs != null) {
            for (SystemObject afterSysObj : afterSysObjs) {
                String sysCode = afterSysObj.getSystemCode();
                String lid = afterSysObj.getLID();
                PersonObject afterPerson = (PersonObject) afterSysObj.getObject();
                if (beforeImage != null) {
                    SystemObject beforeSysObj = beforeImage.getSystemObject(sysCode, lid);
                    if (beforeSysObj != null) {
                        PersonObject beforePerson = (PersonObject) beforeSysObj.getObject();
                        AddressSet beforeAddresses = new AddressSet();
                        beforeAddresses.addAddresses(beforePerson.getAddress());
                        AddressSet afterAddresses = new AddressSet();
                        afterAddresses.addAddresses(afterPerson.getAddress());
                        Collection addresses = afterPerson.getAddressHistory();
                        HashSet<String> existingAddresses = new HashSet();
                        for (Object address : addresses) {
                            AddressHistoryObject addressHistory = (AddressHistoryObject) address;
                            existingAddresses.add(addressToString(addressHistory));
                        }
                        for (AddressObject beforeAddress : beforeAddresses.getAddresses()) {
                             AddressObject afterAddress = afterAddresses.getAddress(beforeAddress);
                             String beforeAddressString = addressToString(beforeAddress);
                             if (afterAddress == null || afterAddress.isRemoved() || !beforeAddressString.equals(addressToString(afterAddress))) {
                                 if (!existingAddresses.contains(beforeAddressString)) {
                                     AddressHistoryObject addressHistory = new AddressHistoryObject();
                                     addressHistory.setAddressType(beforeAddress.getAddressType());
                                     addressHistory.setAddressLine1(beforeAddress.getAddressLine1());
                                     addressHistory.setAddressLine2(beforeAddress.getAddressLine2());
                                     addressHistory.setAddressLine3(beforeAddress.getAddressLine3());
                                     addressHistory.setAddressLine4(beforeAddress.getAddressLine4());
                                     addressHistory.setCity(beforeAddress.getCity());
                                     addressHistory.setCountryCode(beforeAddress.getCountryCode());
                                     addressHistory.setCounty(beforeAddress.getCounty());
                                     addressHistory.setPostalCode(beforeAddress.getPostalCode());
                                     addressHistory.setPostalCodeExt(beforeAddress.getPostalCodeExt());
                                     addressHistory.setHouseNumber(beforeAddress.getHouseNumber());
                                     addressHistory.setStateCode(beforeAddress.getStateCode());
                                     addressHistory.setStreetDir(beforeAddress.getStreetDir());
                                     addressHistory.setStreetName(beforeAddress.getStreetName());
                                     addressHistory.setStreetType(beforeAddress.getStreetType());

                                     /* Uncomment out for address normalization */
                                     /* BEGIN: Normalized Address !!
                                     addressHistory.setNormStreet(beforeAddress.getNormStreet());
                                     addressHistory.setNormAddrDisp(beforeAddress.getNormAddrDisp());
                                     addressHistory.setNormAddrLine(beforeAddress.getNormAddrLine());
                                     addressHistory.setLatitude(beforeAddress.getLatitude());
                                     addressHistory.setLongitude(beforeAddress.getLongitude());
                                     addressHistory.setNormHouseNum(beforeAddress.getNormHouseNum());
                                     addressHistory.setNormPostBox(beforeAddress.getNormPostBox());
                                     addressHistory.setNormState(beforeAddress.getNormState());
                                     addressHistory.setNormCountry(beforeAddress.getNormCountry());
                                     addressHistory.setNormCity(beforeAddress.getNormCity());
                                     addressHistory.setNormPostCode(beforeAddress.getNormPostCode());
                                     addressHistory.setNormAccuracy(beforeAddress.getNormAccuracy());
                                     addressHistory.setVerificationStatus(beforeAddress.getVerificationStatus());
                                     !! END: Normalized Address */

                                     afterPerson.addAddressHistory(addressHistory);
                                     existingAddresses.add(beforeAddressString);
                                 }
                             }
                        }
                    }
                }
            }
        }
    }

    public static void geocodeEnterpriseObject(EnterpriseObject eo) {
        Collection c = eo.getSystemObjects();
        Iterator sysobjs = c.iterator();
        PersonObject[] person = new PersonObject[c.size() + 1];
        person[0] = ((PersonObject) eo.getSBR().getObject());
        for (int i = 1; i < person.length; ++i) {
            person[i] = ((PersonObject) ((SystemObject) sysobjs.next()).getObject());
        }
        for (PersonObject p : person) {
            Collection addresses = p.getAddress();
            for (Object o : addresses) {
                geocodeAddress((AddressObject)o);
            }
        }
    }

    public static void geocodeAddress(AddressObject addr)
    {
        try {
            AddressGeoCodeResult res = AddressGeoCode.getGeocode(addr.getAddressLine1(),
                    addr.getCity(), addr.getPostalCode(), addr.getStateCode());
            addr.setLatitude(res.getLatitude());
            addr.setLongitude(res.getLongitude());
        } catch (Exception e) {
            //TODO: Need to add a geocode status flag and indicate success or failure
            e.printStackTrace();
        }
    }

}
