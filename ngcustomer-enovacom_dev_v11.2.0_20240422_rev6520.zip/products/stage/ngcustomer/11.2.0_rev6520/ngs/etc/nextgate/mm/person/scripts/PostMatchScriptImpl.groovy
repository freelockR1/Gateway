import com.nextgate.interfaces.mm.exceptions.MatchException
import com.nextgate.mm.common.datatypes.falsepos.FalsePositiveCode
import com.nextgate.mm.common.datatypes.match.CompositeMatchWeight
import com.nextgate.mm.common.datatypes.match.MatchFunction
import com.nextgate.mm.common.datatypes.match.MatchWeight
import com.nextgate.mm.matcher.PostMatchContext
import com.nextgate.mm.matcher.PostMatchScript
import org.slf4j.Logger
import org.slf4j.LoggerFactory

import java.text.NumberFormat 
/**
 * Sample post matching script. To enable this post match script you
 * need to add a row to MM_CFG_APPLICATION with a key of POST_MATCH_SCRIPT and
 * a value of PostMatchScriptImpl.
 */
public class PostMatchScriptImpl implements PostMatchScript {
    private static final Logger LOG = LoggerFactory.getLogger(PostMatchScriptImpl.class);

    private int mFirstNameMatchFunctionIndex = -1;
    private int mFirstNameExactMatchFunctionIndex = -1;
    private int mFirstNameAllMatchFunctionIndex = -1;
    private int mLastNameMatchFunctionIndex = -1;
    private int mMiddleNameMatchFunctionIndex = -1;
    private int mDOBMatchFunctionIndex = -1;
    private int mPhoneMatchFunctionIndex = -1;
    private int mStreetNameFunctionIndex = -1;
    private int mHouseNumberFunctionIndex = -1;
    private int mCityFunctionIndex = -1;
    private int mStateFunctionIndex = -1;
    private int mPostalCodeFunctionIndex = -1;
    private int mRuralRouteFunctionIndex = -1;
    private int mPOBoxFunctionIndex = -1;
    private int mAddressPhoneIndex = -1;
    private int mDistanceMatchFunctionIndex = -1;
    private int mGenderMatchFunctionIndex = -1;
    private int mCityOfBirthFunctionIndex = -1;
    private int mINSFunctionIndex = -1;
    private int mATTRHOMAFunctionIndex = -1;	
    private int mATTRDOUTFunctionIndex = -1;	
    private int mATTRFICTFunctionIndex = -1;
    private int mOLDEMPIFunctionIndex = -1;	

    private final ThreadLocal<NumberFormat> mNumberFormat;

    private MatchFunction[] matchFunctionArray;

    public PostMatchScriptImpl() {
        mNumberFormat = new ThreadLocal<NumberFormat>() {

            @Override
            protected NumberFormat initialValue() {

                NumberFormat ret = NumberFormat.getNumberInstance();
                ret.setMaximumFractionDigits(2);
                return ret;

            }
        }
    }

    /**
     * Reduce negative weighting for last name mismatches when gender is female.
	 * Also apply a false positive for records with insufficient data.
     * @param matchFunctions array of match functions
     * @param c The composite match weight
     * @param recA The data being matched
     * @param recB The data being matched
     * @throws MatchException
     */
    public void apply(PostMatchContext postMatchContext) throws MatchException {
        String[][] recA = postMatchContext.getRecA();
        String[][] recB = postMatchContext.getRecB();

        CompositeMatchWeight c = postMatchContext.getCompositeMatchWeight();
        int indexFirstName = -1;
        int indexFirstNameExact = -1;
        int indexFirstNameAll = -1;
        int indexLastName = -1;
        int indexMiddleName = -1;
        int indexDOB = -1;
        int indexPhone = -1;
        int indexStreetName = -1;
        int indexHouseNumber = -1;
        int indexCity = -1;
        int indexState = -1;
        int indexPostalCode = -1;
        int indexRuralRoute = -1;
        int indexPOBox = -1;
        int indexDistance = -1;
        int indexAddressPhone = -1;
        int indexGender = -1;
        int indexCityOfBirth = -1;
        int indexINS = -1;
        int indexATTRHOMA = -1;
        int indexATTRDOUT = -1;
        int indexATTRFICT = -1;
        int indexOldEmpi = -1;
        boolean insufficientData = false;

        int[] matchFieldIndexes = c.getMatchFieldIndexes();
        MatchWeight[] matchWeights = c.getMatchWeights();
        
        List<String> mismatchFields = new ArrayList<>();

        for (int i = 0; i < c.getMatchWeights().length; i++) {
            // Note that the array of match weights in the composite match weight
            // is not guaranteed to be in the same order as the match functions
            // array.  The matchFieldIndexes property must be used to find
            // the appropriate position within the match weights array.
            if (matchFieldIndexes[i] == mFirstNameMatchFunctionIndex) {
                indexFirstName = i;
            } else if (matchFieldIndexes[i] == mFirstNameExactMatchFunctionIndex) {
                indexFirstNameExact = i;
            } else if (matchFieldIndexes[i] == mFirstNameAllMatchFunctionIndex) {
                indexFirstNameAll = i;
            } else if (matchFieldIndexes[i] == mLastNameMatchFunctionIndex) {
                indexLastName = i;
            } else if (matchFieldIndexes[i] == mMiddleNameMatchFunctionIndex) {
                indexMiddleName = i;
            } else if (matchFieldIndexes[i] == mDOBMatchFunctionIndex) {
                indexDOB = i;
            } else if (matchFieldIndexes[i] == mStreetNameFunctionIndex) {
                indexStreetName = i;
            } else if (matchFieldIndexes[i] == mHouseNumberFunctionIndex) {
                indexHouseNumber = i;
            } else if (matchFieldIndexes[i] == mCityFunctionIndex) {
                indexCity = i;
            } else if (matchFieldIndexes[i] == mStateFunctionIndex) {
                indexState = i;
            } else if (matchFieldIndexes[i] == mPostalCodeFunctionIndex) {
                indexPostalCode = i;
            } else if (matchFieldIndexes[i] == mRuralRouteFunctionIndex) {
                indexRuralRoute = i;
            } else if (matchFieldIndexes[i] == mPOBoxFunctionIndex) {
                indexPOBox = i;
            } else if (matchFieldIndexes[i] == mDistanceMatchFunctionIndex) {
                indexDistance = i;
            } else if (matchFieldIndexes[i] == mAddressPhoneIndex) {
                indexAddressPhone = i;
            } else if (matchFieldIndexes[i] == mPhoneMatchFunctionIndex) {
                indexPhone = i;
            } else if (matchFieldIndexes[i] == mINSFunctionIndex) {
                indexINS = i;
            } else if (matchFieldIndexes[i] == mATTRHOMAFunctionIndex) {
                indexATTRHOMA = i;
            } else if (matchFieldIndexes[i] == mATTRDOUTFunctionIndex) {
                indexATTRDOUT = i;
            } else if (matchFieldIndexes[i] == mATTRFICTFunctionIndex) {
                indexATTRFICT = i;
            } else if (matchFieldIndexes[i] == mGenderMatchFunctionIndex) {
                indexGender = i;
            } else if (matchFieldIndexes[i] == mCityOfBirthFunctionIndex) {
                indexCityOfBirth = i;
            } else if (matchFieldIndexes[i] == mOLDEMPIFunctionIndex) {
                indexOldEmpi = i;
            }
        }

        // Check for at least 2 strong identifiers in the record
        int identifierCount = 0;
        if (indexPhone != -1 && !matchWeights[indexPhone].isEmptyOrExcluded) {
            identifierCount++;
        }
        if (indexStreetName != -1 && !matchWeights[indexStreetName].isEmptyOrExcluded) {
            identifierCount++;
        }
        if (indexFirstName != -1 && !matchWeights[indexFirstName].isEmptyOrExcluded &&
                indexLastName != -1 && !matchWeights[indexLastName].isEmptyOrExcluded) {
            identifierCount++;
        }
        if (indexDOB != -1 && !matchWeights[indexDOB].isEmptyOrExcluded) {
            identifierCount++;
        }
        if (identifierCount < 2) {
            addFalsePositive(c, "INSUFFICIENTDATA", "Données insuffisantes");
            insufficientData = true;
        }
        if(indexDistance != -1 && isGeoSearch(recA[mDistanceMatchFunctionIndex], recB[mDistanceMatchFunctionIndex])) {
            // Get address/phone group weight adjustment
            MatchWeight addressPhoneWeight = getAddressPhoneWeight(c.getWeightExplanation());
            String oldAddressPhoneWeightExplain = addressPhoneWeight.weightExplanation;

            // Remove address match weight for geo search
            addressPhoneWeight = zeroAddressWeight(c, indexStreetName, "STREET_NAME", addressPhoneWeight);
            addressPhoneWeight = zeroAddressWeight(c, indexHouseNumber, "HOUSE_NUMBER", addressPhoneWeight);
            addressPhoneWeight = zeroAddressWeight(c, indexCity, "CITY", addressPhoneWeight);
            addressPhoneWeight = zeroAddressWeight(c, indexState, "STATE", addressPhoneWeight);
            addressPhoneWeight = zeroAddressWeight(c, indexPostalCode, "POSTAL_CODE", addressPhoneWeight);
            addressPhoneWeight = zeroAddressWeight(c, indexRuralRoute, "RURAL_ROUTE", addressPhoneWeight);
            addressPhoneWeight = zeroAddressWeight(c, indexPOBox, "PO_BOX", addressPhoneWeight);
            c.setWeightExplanation(c.getWeightExplanation().replace(oldAddressPhoneWeightExplain, "ADDRESS_PHONE[" + mNumberFormat.get().format(addressPhoneWeight.weight) + "]"));
        }
		
		// Enovacom custom START
        boolean FirstNameEmpty = (indexFirstName != -1) && (matchWeights[indexFirstName].isEmptyOrExcluded);
        boolean LastNameEmpty = (indexLastName != -1) && (matchWeights[indexLastName].isEmptyOrExcluded);
        boolean DOBEmpty = (indexDOB != -1) && (matchWeights[indexDOB].isEmptyOrExcluded);
        boolean GenderEmpty = (indexGender != -1) && (matchWeights[indexGender].isEmptyOrExcluded);
        boolean CityEmpty = (indexCity != -1) && (matchWeights[indexCity].isEmptyOrExcluded);
        boolean CityOfBirthEmpty = (indexCityOfBirth != -1) && (matchWeights[indexCityOfBirth].isEmptyOrExcluded);
        boolean INSEmpty = (indexINS != -1) && (matchWeights[indexINS].isEmptyOrExcluded);

        // Traits Strict
        if (!insufficientData && ((FirstNameEmpty || LastNameEmpty || DOBEmpty || GenderEmpty) || (CityEmpty && CityOfBirthEmpty && INSEmpty))) {
            addFalsePositive(c, "INSUFFICIENTDATA", "Données insuffisantes");
        }

		// If the invariable first first name is not filled in on both identities or is not exactly the same: False positive – JUMEAUXPOTENTIELS
        if (indexFirstNameExact != -1 && (matchWeights[indexFirstNameExact].isEmptyOrExcluded || matchWeights[indexFirstNameExact].similarity < 1.0f)) {
            addFalsePositive(c, "JUMEAUXPOTENTIELS", "Jumeaux potentiels");
        }

		// If the INS number is filled in on both identities and different: False positive – MATRICULESINSDIFF 
        if (indexINS != -1 && !matchWeights[indexINS].isEmptyOrExcluded && matchWeights[indexINS].similarity < 1.0f) {
            addFalsePositive(c, "MATRICULESINSDIFF", "Matricules INS différents");
        }

		// If at least one of the two identities has an attribute (IdentityAttribute) of filled in (cf 3.2.7): False positive – ATTRIBUTDETECTE
        if (isSet(recA[mATTRHOMAFunctionIndex], recB[mATTRHOMAFunctionIndex]) || isSet(recA[mATTRDOUTFunctionIndex], recB[mATTRDOUTFunctionIndex]) || isSet(recA[mATTRFICTFunctionIndex], recB[mATTRFICTFunctionIndex])) {
            addFalsePositive(c, "ATTRIBUTDETECTE", "Attribut detecte");
        }

        // If ID_ANCIEN_SRI is a match and the weight is > 0 then remove all FalsePositives
        if(indexOldEmpi != -1 && !matchWeights[indexOldEmpi].isEmptyOrExcluded && matchWeights[indexOldEmpi].similarity == 1.0f && matchWeights[indexOldEmpi].weight > 0.0f) {
            c.getFalsePositiveFlags().clear();
        }
        // Enovacom custom END
    }

    private MatchWeight copyMatchWeight(MatchWeight mw, float newWeight) {
        return new MatchWeight(newWeight, mw.similarity, mw.isEquiv, mw.isEmptyOrExcluded, mw.weightExplanation, mw.falsePositiveFlags);
    }

    public void applyPreWeightComposition(PostMatchContext postMatchContext) throws MatchException {
        String[][] recA = postMatchContext.getRecA();
        String[][] recB = postMatchContext.getRecB();

        CompositeMatchWeight c = postMatchContext.getCompositeMatchWeight();
        int indexFirstName = -1;
        int indexLastName = -1;
        int indexMiddleName = -1;
        int indexDOB = -1;
        int indexPhone = -1;
        int indexStreetName = -1;
        int indexHouseNumber = -1;
        int indexCity = -1;
        int indexState = -1;
        int indexPostalCode = -1;
        int indexRuralRoute = -1;
        int indexPOBox = -1;
        int indexDistance = -1;
        int indexAddressPhone = -1;
        int indexGender = -1;
        int indexCityOfBirth = -1;
        int indexINS = -1;

        int[] matchFieldIndexes = c.getMatchFieldIndexes();
        MatchWeight[] matchWeights = c.getMatchWeights();
        
        for (int i = 0; i < c.getMatchWeights().length; i++) {
            // Note that the array of match weights in the composite match weight
            // is not guaranteed to be in the same order as the match functions
            // array.  The matchFieldIndexes property must be used to find
            // the appropriate position within the match weights array.
            if (matchFieldIndexes[i] == mFirstNameMatchFunctionIndex) {
                indexFirstName = i;
            } else if (matchFieldIndexes[i] == mLastNameMatchFunctionIndex) {
                indexLastName = i;
            } else if (matchFieldIndexes[i] == mMiddleNameMatchFunctionIndex) {
                indexMiddleName = i;
            } else if (matchFieldIndexes[i] == mDOBMatchFunctionIndex) {
                indexDOB = i;
            } else if (matchFieldIndexes[i] == mStreetNameFunctionIndex) {
                indexStreetName = i;
            } else if (matchFieldIndexes[i] == mHouseNumberFunctionIndex) {
                indexHouseNumber = i;
            } else if (matchFieldIndexes[i] == mCityFunctionIndex) {
                indexCity = i;
            } else if (matchFieldIndexes[i] == mStateFunctionIndex) {
                indexState = i;
            } else if (matchFieldIndexes[i] == mPostalCodeFunctionIndex) {
                indexPostalCode = i;
            } else if (matchFieldIndexes[i] == mRuralRouteFunctionIndex) {
                indexRuralRoute = i;
            } else if (matchFieldIndexes[i] == mPOBoxFunctionIndex) {
                indexPOBox = i;
            } else if (matchFieldIndexes[i] == mDistanceMatchFunctionIndex) {
                indexDistance = i;
            } else if (matchFieldIndexes[i] == mAddressPhoneIndex) {
                indexAddressPhone = i;
            } else if (matchFieldIndexes[i] == mPhoneMatchFunctionIndex) {
                indexPhone = i;
            } else if (matchFieldIndexes[i] == mINSFunctionIndex) {
                indexINS = i;
            } else if (matchFieldIndexes[i] == mGenderMatchFunctionIndex) {
                indexGender = i;
            } else if (matchFieldIndexes[i] == mCityOfBirthFunctionIndex) {
                indexCityOfBirth = i;
            }
        }

        if (mGenderMatchFunctionIndex != -1 && indexLastName != -1) {

            MatchWeight mwLast = matchWeights[indexLastName];

            if (isFemale(recA[mGenderMatchFunctionIndex], recB[mGenderMatchFunctionIndex]) && mwLast.weight < 0.0f) {

                //adjust score of last name
                float adjustment = Math.abs((float) (mwLast.weight / 2));
                matchWeights[indexLastName] = new MatchWeight(-adjustment, mwLast.similarity, mwLast.isEquiv, mwLast.isEmptyOrExcluded, mwLast.weightExplanation, mwLast.falsePositiveFlags);
            }
        }
    }

    private MatchWeight getAddressPhoneWeight(String weightExplanation) {
        String findString = "ADDRESS_PHONE[";
        int indx = weightExplanation.indexOf(findString);
        if(indx > -1) {
            indx += findString.length();
            String weightStr = weightExplanation.substring(indx, weightExplanation.indexOf("]", indx))
            MatchWeight addressPhoneWeight = new MatchWeight(Float.parseFloat(weightStr), findString + weightStr + "]", null);
            return addressPhoneWeight;
        }
        else {
            return new MatchWeight(0, findString + "0]", null);
        }
    }

    private MatchWeight zeroAddressWeight(CompositeMatchWeight c, int index, String func, MatchWeight addressPhoneWeight) {
        MatchWeight[] matchWeights = c.getMatchWeights();
        MatchWeight mw = matchWeights[index];
        // Save old weight
        String oldWeightExplain = func + "[" + mNumberFormat.get().format(mw.weight) + "]";
        float oldWeight = mw.weight;
        float addressPhoneWeightFlt = addressPhoneWeight.weight;
        // Zero out weight
        matchWeights[index] = new MatchWeight(0, mw.similarity, mw.isEquiv, mw.isEmptyOrExcluded, mw.weightExplanation, mw.falsePositiveFlags);
        c.setWeightExplanation(c.getWeightExplanation().replace(oldWeightExplain, func + "[0]"));

        // Adjust overall weight
        float adjustment = 0;
        if(addressPhoneWeightFlt < 0) {
            // No weight was given to overall weight because of address/phone group, remove weight from offset
            addressPhoneWeightFlt += oldWeight;
            if(addressPhoneWeightFlt > 0) {
                // If address/phone group offset is now positive then decrement this from the overall weight and zero out address/phone offset
                adjustment = addressPhoneWeightFlt;
                addressPhoneWeightFlt = 0;
            }
        }
        else {
            // Address/phone offset is not applicable, decrement overall weight
            adjustment = oldWeight;
        }
        c.setWeight((float) (c.getWeight()-adjustment));

        return new MatchWeight(addressPhoneWeightFlt, null, null);
    }

    private boolean isGeoSearch(String[] dist1, String[] dist2) {
        if (dist1 != null && dist1.length > 0 && dist1[0] != null && !dist1[0].isEmpty()) {
            return true;
        }
        if (dist2 != null && dist2.length > 0 && dist2[0] != null && !dist2[0].isEmpty()) {
            return true;
        }
        return false;
    }

    private boolean isFemale(String[] gender1, String[] gender2) {
        int count = 0;
        if (gender1 != null && gender1.length > 0 && gender1[0] != null) {
            if (gender1[0].equals("F")) {
                count++;
            } else if (gender1[0].equals("M")) {
                count--;
            }
        }
        if (gender2 != null && gender2.length > 0 && gender2[0] != null) {
            if (gender2[0].equals("F")) {
                count++;
            } else if (gender2[0].equals("M")) {
                count--;
            }
        }
        return count >= 1;
    }

    private boolean isSet(String[] val1, String[] val2) {
        boolean val1Set = val1 != null && val1.length > 0 && "Y".equals(val1[0]);
        boolean val2Set = val2 != null && val2.length > 0 && "Y".equals(val2[0]);
        return val1Set || val2Set;
    }

    private void addFalsePositive(CompositeMatchWeight c, String code, String description) {
        for(FalsePositiveCode fp : c.getFalsePositiveFlags()) {
            if(fp.getCode().equals(code) || fp.getDescription().equals(description)) {
                // Duplicate FP
                return;
            }
        }

        FalsePositiveCode fp = new FalsePositiveCode(code);
        fp.setDescription(description);
        c.getFalsePositiveFlags().add(fp);
    }

    /**
     * Initialization will determine if GIVEN_NAME and other match function exist
     * and their index position within the array of match functions.
     *
     * @param matchFunctions
     * @throws MatchException
     */
    public void init(MatchFunction[] matchFunctions) throws MatchException {
        matchFunctionArray = matchFunctions
        for (int i = 0; i < matchFunctions.length; i++) {
            MatchFunction func = matchFunctions[i];
            if (func.getName().equals("PRENOM")) {
                mFirstNameMatchFunctionIndex = i;
            } else if (func.getName().equals("EXACT_PRENOM")) {
                mFirstNameExactMatchFunctionIndex = i;
            } else if (func.getName().equals("PRENOM_LISTE")) {
                mFirstNameAllMatchFunctionIndex = i;
            } else if (func.getName().equals("NOM_DE_NAISSANCE")) {
                mLastNameMatchFunctionIndex = i;
            } else if (func.getName().equals("PRENOM_UTILISE")) {
                mMiddleNameMatchFunctionIndex = i;
            } else if (func.getName().equals("DDN")) {
                mDOBMatchFunctionIndex = i;
            } else if (func.getName().equals("PHONE")) {
                mPhoneMatchFunctionIndex = i;
            } else if (func.getName().equals("STREET_NAME")) {
                mStreetNameFunctionIndex = i;
            } else if (func.getName().equals("HOUSE_NUMBER")) {
                mHouseNumberFunctionIndex = i;
            } else if (func.getName().equals("ADRESSE_VILLE")) {
                mCityFunctionIndex = i;
            } else if (func.getName().equals("STATE")) {
                mStateFunctionIndex = i;
            } else if (func.getName().equals("POSTAL_CODE")) {
                mPostalCodeFunctionIndex = i;
            } else if (func.getName().equals("RURAL_ROUTE")) {
                mRuralRouteFunctionIndex = i;
            } else if (func.getName().equals("PO_BOX")) {
                mPOBoxFunctionIndex = i;
            } else if (func.getName().equals("DISTANCE")) {
                mDistanceMatchFunctionIndex = i;
            } else if (func.getName().equals("ADDRESS_PHONE")) {
                mAddressPhoneIndex = i;
            } else if (func.getName().equals("SEXE")) {
                mGenderMatchFunctionIndex = i;
            } else if (func.getName().equals("VILLE_DE_NAISSANCE")) {
                mCityOfBirthFunctionIndex = i;
            } else if (func.getName().equals("MATRICULE_INS")) {
                mINSFunctionIndex = i;
            } else if (func.getName().equals("ATTR_HOMONYME")) {
                mATTRHOMAFunctionIndex = i;
            } else if (func.getName().equals("ATTR_DOUTEUSE")) {
                mATTRDOUTFunctionIndex = i;
            } else if (func.getName().equals("ATTR_FICTIVE")) {
                mATTRFICTFunctionIndex = i;
            } else if (func.getName().equals("ID_ANCIEN_SRI")) {
                mOLDEMPIFunctionIndex = i;
            }
        }
    }
}
