import com.nextgate.interfaces.mm.exceptions.MatchException
import com.nextgate.mm.common.datatypes.match.MatchFunction
import com.nextgate.mm.matcher.MatchContext
import com.nextgate.mm.matcher.PreMatchScript
import org.slf4j.Logger
import org.slf4j.LoggerFactory

/**
 * Sample pre matching script that pads the SSN with leading zeros prior to
 * making the comparison.  Note that a standardizer function could perform
 * this function more efficiently and this is only an example for illustrative 
 * purposes.  To enable this pre match script you will need to add a row to
 * MM_CFG_APPLICATION with a key of PRE_MATCH_SCRIPT and a value of PreMatchScriptImpl.
 */
public class PreMatchScriptImpl implements PreMatchScript {
    private static final Logger LOG = LoggerFactory.getLogger(PreMatchScriptImpl.class);

    private int mNomUtiliseMatchFunctionIndex = -1;
    private int mNomDeNaissanceMatchFunctionIndex = -1;
    private int mPrenomMatchFunctionIndex = -1;
    private int mPrenomListeMatchFunctionIndex = -1;

    /**
     * Pad SSN if necessary
     * @param matchFunctions array of match functions
     * @param recA The data being matched
     * @param recB The data being matched
     * @throws MatchException
     */
    public void apply(MatchContext matchContext) throws MatchException {
        String[][] recA = matchContext.getRecA();
        String[][] recB = matchContext.getRecB();
        removeDupLastNames(recA);
        removeDupLastNames(recB);
        removeDupFirstNames(recA);
        removeDupFirstNames(recB);
    }

    private void removeDupLastNames(String[][] rec) {
        String[] nomUtiliseNames = rec[mNomUtiliseMatchFunctionIndex];
        String[] nomDeNaissance = rec[mNomDeNaissanceMatchFunctionIndex];
        removeDups(nomUtiliseNames, nomDeNaissance);
    }

    private void removeDupFirstNames(String[][] rec) {
        String[] prenomNames = rec[mPrenomMatchFunctionIndex];
        String[] prenomListeNames = rec[mPrenomListeMatchFunctionIndex];
        removeDups(prenomListeNames, prenomNames);
    }

    // Remove dups in val1 that exist in val2
    private void removeDups(String[] val1, String[] val2) {
        String str1 = val1[0];
        String str2 = val2[0];
        if(str1 != null && str2 != null) {
            for(String s : str2.split('#|\\s')) {
                // Replace the name where it is at the start, preceeded by whitespace, or preceeded by #
                String regex = '^' + s + '|\\s' + s + '|#' + s;
                str1 = str1.replaceAll(regex, '');
            }
            str1 = str1.trim();
            if(str1.isEmpty() || str1.replaceAll('#', '').isEmpty()) {
                str1 = null;
            }
            val1[0] = str1;
        }
    }

    public void init(MatchFunction[] matchFunctions) throws MatchException {
        // Find the SSN match functions
        for (int i = 0; i < matchFunctions.length; i++) {
            MatchFunction func= matchFunctions[i];
            if (func.getName().equals("NOM_UTILISE")) {
                mNomUtiliseMatchFunctionIndex = i;
            }
            else if (func.getName().equals("NOM_DE_NAISSANCE")) {
                mNomDeNaissanceMatchFunctionIndex = i;
            }
            else if (func.getName().equals("PRENOM")) {
                mPrenomMatchFunctionIndex = i;
            }
            else if (func.getName().equals("PRENOM_LISTE")) {
                mPrenomListeMatchFunctionIndex = i;
            } 
        }
    }
    
}