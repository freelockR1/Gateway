/*
Copyright (c) 2014, NextGate Solutions All Rights Reserved.

This program, and all the NextGate Solutions authored routines referenced herein,
are the proprietary properties and trade secrets of NextGate Solutions.

Except as provided for by license agreement, this program shall not be duplicated,
used, reversed engineered, decompiled, disclosed, shared, transferred, placed in a
publicly available location (such as but not limited to ftp sites, bit torrents,
shared drives, peer to peer networks, and such) without  written consent signed by
an officer of NextGate Solutions.

DISCLAIMER:

This software is provided as is without warranty of any kind. The entire risk as to
the results and performance of this software is assumed by the licensee and/or its
affiliates and/or assignees. NextGate Solutions disclaims all warranties, either
expressed or implied, including but not limited to the implied warranties of
merchantability, fitness for a particular purpose, title and non-infringement, with
respect to this software.

- version control -
$Id: WorkflowTaskGeneratorPersonPotentialMatchImpl.groovy 36209 2018-11-07 18:58:19Z kevin.schmidt $
 */

import java.text.NumberFormat;

import com.nextgate.core.utils.DateUtils;
import com.nextgate.ms.component.adapter.sender.workflow.interfaces.PotentialMatchContext;
import com.nextgate.ms.component.adapter.sender.workflow.interfaces.PotentialMatchTaskGenerator;
import com.nextgate.ms.component.adapter.sender.workflow.interfaces.WorkflowTask;
import com.nextgate.ms.core.exceptions.AdapterException;
import com.sun.mdm.index.objects.ObjectNode;
import com.sun.mdm.index.objects.SystemObjectPK;
import com.sun.mdm.index.objects.exception.ObjectException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.slf4j.Logger
import org.slf4j.LoggerFactory

/**
 * Customizable class to handle the potential match work flows from the MM Notifications.
 *
 * @author Peter Berkman
 * @version $Revision: 36209 $
 * @since 9.0.0
 */
public class WorkflowTaskGeneratorPersonPotentialMatchImpl implements PotentialMatchTaskGenerator {
    private static final Logger LOG = LoggerFactory.getLogger(WorkflowTaskGeneratorPersonPotentialMatchImpl.class);

    private static final String PROC_DEF_KEY = "PersonPotentialMatch";
    private Properties systemAssignee = new Properties();
    private long systemAssigneeFileDate = 0l;

    public WorkflowTaskGeneratorPersonPotentialMatchImpl() {
    }

    @Override
    public WorkflowTask generateTask(PotentialMatchContext context) throws AdapterException {
        WorkflowTask task = new WorkflowTask();

        task.setProcessDefinitionKey(PROC_DEF_KEY);

        task.setSummaryText(generateSummary(context));

        Map<String, String> formProperties = new HashMap<>();

        formProperties.put("euid1", context.getEUID1());
        formProperties.put("euid2", context.getEUID2());
        formProperties.put("potentialDuplicateId", context.getComparison().getId());
        formProperties.put("appName", "Person");
        formProperties.put("weight", ((Double) context.getComparison().getOverallScore()).toString());
        formProperties.put("ids", this.generateIds(context));
        formProperties.put("assignees", this.generateAssignees(context));

        if (context.getMessage() != null && context.getMessage().getCanonicalData() != null && !context.getMessage().getCanonicalData().isEmpty()) {
            formProperties.put("registrar", context.getMessage().getCanonicalData().get(0).getPerson().getCreateUser());
        }

        task.setFormProperties(formProperties);

        assignLabels(task, context);

        return task;
    }

    private String generateIds(PotentialMatchContext context) {
        StringBuilder sb = new StringBuilder();

        sb.append(",")
            .append("EUID/").append(context.getEUID1()).append(",")
            .append("EUID/").append(context.getEUID2()).append(",");

        for (SystemObjectPK pk : context.getSystemObjectKeys1()) {
            sb.append(pk.systemCode)
                .append("/")
                .append(pk.lID)
                .append(",");
        }

        for (SystemObjectPK pk : context.getSystemObjectKeys2()) {
            sb.append(pk.systemCode)
                .append("/")
                .append(pk.lID)
                .append(",");
        }

        return sb.toString();
    }

    private String generateAssignees(PotentialMatchContext context) {
        Set<String> systems = new TreeSet<>();
        // Aggregate list of system codes
        for (SystemObjectPK pk : context.getSystemObjectKeys1()) {
            systems.add(pk.systemCode);
        }

        for (SystemObjectPK pk : context.getSystemObjectKeys2()) {
            systems.add(pk.systemCode);
        }

        return String.join(",", systems);
    }

    private void assignLabels(WorkflowTask task, PotentialMatchContext context) {
        List<String> labels = new ArrayList<>();

        ObjectNode obj1 = context.getSBR1().getObject();
        ObjectNode obj2 = context.getSBR2().getObject();

        String flag1 = (String) obj1.getValue("VIPFlag");
        String flag2 = (String) obj2.getValue("VIPFlag");

        if (flag1 != null || flag2 != null) {
            labels.add("vip");
        }

        if (context.getComparison().getFalsePositives() != null && !context.getComparison().getFalsePositives().isEmpty()) {
            labels.add("faux-positifs");
        }

        String systemCode1 = null;
        boolean crossSystem = false;
        for (SystemObjectPK pk : context.getSystemObjectKeys1()) {
            if(systemCode1 == null) {
                systemCode1 = pk.systemCode;
            }
            if(!pk.systemCode.equals(systemCode1)) {
                crossSystem = true;
                break;
            }
        }
        if(!crossSystem) {
            for (SystemObjectPK pk : context.getSystemObjectKeys2()) {
                if(systemCode1 == null) {
                    systemCode1 = pk.systemCode;
                }
                if(!pk.systemCode.equals(systemCode1)) {
                    crossSystem = true;
                    break;
                }
            }
        }

        task.setLabels(labels);

        // set security label indicating cross-system
        if(crossSystem) {
            List<String> sLabels = new ArrayList<>(1);
            sLabels.add("cross-system");
            task.setSecurityLabels(sLabels);
        }
    }

    private String generateSummary(PotentialMatchContext context) throws AdapterException {

        NumberFormat nf = NumberFormat.getInstance();

        nf.setMaximumFractionDigits(2);
        nf.setMinimumFractionDigits(2);

        ObjectNode obj1 = context.getSBR1().getObject();
        ObjectNode obj2 = context.getSBR2().getObject();

        // try to get a US model field to determine model
        boolean intlModel = true;
        try {
            if (obj1.getField("FirstName") != null) {
                intlModel = false;
            }
        } catch (ObjectException ex) {
            // US model field not found, assume INTL
        }

        StringBuilder sb = new StringBuilder();

        sb.append(_generateSummary(obj1, context.getEUID1(), intlModel)).append("\n");
        sb.append(_generateSummary(obj2, context.getEUID2(), intlModel)).append("\n");
        sb.append("Poid: ").append(nf.format(context.getComparison().getOverallScore()));

        if (context.getComparison().getFalsePositives() != null) {
            for (String fp : context.getComparison().getFalsePositives()) {
                sb.append("\n").append(fp);
            }
        }

        return sb.toString();
    }

    private String _generateSummary(ObjectNode obj, String euid, boolean intlModel) throws AdapterException {
        try {
            String firstName;
            String lastName;
            String dobString = null;
            String id;
            Date dob;

            if (intlModel) {
                firstName = (String) obj.getValue("GivenName");
                lastName = (String) obj.getValue("FamilyName");
                dob = (Date) obj.getValue("DateOfBirth");
                if (dob != null) {
                    dobString = DateUtils.formatDateTime(dob, "dd/MM/yyyy");
                }
                id = (String) obj.getValue("NationalID");
            } else {
                firstName = (String) obj.getValue("FirstName");
                lastName = (String) obj.getValue("LastName");
                dob = (Date) obj.getValue("DOB");
                if (dob != null) {
                    dobString = DateUtils.formatDateTime(dob, "MM/dd/yyyy");
                }
                id = (String) obj.getValue("SSN");
            }

            StringBuilder sb = new StringBuilder();
            sb.append("EUID ").append(euid).append(": ");
            boolean first = true;
            if (firstName != null && firstName.length() > 0) {
                sb.append(firstName);
                first = false;
            }
            if (lastName != null && lastName.length() > 0) {
                if (!first) {
                    sb.append(", ");
                }
                sb.append(lastName);
                first = false;
            }
            if (dobString != null) {
                if (!first) {
                    sb.append(", ");
                }
                sb.append(dobString);
                first = false;
            }
            if (id != null && id.length() > 0) {
                if (!first) {
                    sb.append(", ");
                }
                sb.append(id);
//                first = false;
            }
            return sb.toString();
        } catch (Exception e) {
            throw new AdapterException("Failed to generate task summary", e);
        }
    }
}
